// Nonnon Jpeg
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ] : when using DLL : slower version : currently not needed
//
//	http://gnuwin32.sourceforge.net/packages/jpeg.htm
//
//	[ How to Get ]
//
//	1 : click "Binaries"        to get "jpeg-bin-zip.php"
//	2 : click "Developer files" to get "jpeg-lib-zip.php"
//	3 : done!
//
//	[ How to Install ]
//
//	1 : merge "include" and "lib" folders into "MinGW/include" "MinGW/lib" folders
//	2 : put "bin/jpeg62.dll" into a "MinGW/bin" folder
//	3 : done!
//
//	[ How to use : for system ]
//
//	1 : #include <jpeglib.h>
//	2 : done!
//
//	[ How to use : for client ]
//
//	1 : include "nonnon/neutral/jpg.c"
//	2 : done!
//
//	[ How to Link ]
//
//	-ljpeg


// [ Mechanism ] : when using DLL : faster version : currently not used
//
//	http://cetus.sakura.ne.jp/softlab/jpeg-x86simd/jpegsimd.html
//	+ 2x faster than original libjpeg
//
//	+ static link is not available
//
//	[ How to Get ]
//
//	1 : download : jpeg6bx102_win32dll.zip
//	2 : done!
//
//	[ How to Install ]
//
//	1 : unzip "devel.zip"
//	2 : copy and rename "lib/jpeg62.lib" to "jpeg.lib"
//	3 : merge "include" and "lib" folders into "MinGW/include" "MinGW/lib" folders
//	4 : put "bin/jpeg62.dll" into a "MinGW/bin" folder
//	5 : done!
//
//	+ don't mix other libjpeg library's header files
//
//	[ How to use : for system ]
//
//	1 : #include <jpeglib.h>
//	2 : done!
//
//	[ How to use : for client ]
//
//	1 : include "nonnon/neutral/jpg.c"
//	2 : done!
//
//	[ How to Link ]
//
//	-ljpeg


// [ Mechanism ] : libjpeg-turbo : when not using DLL : faster version : currently not used
//
//	+ 2x more faster than original libjpeg
//
//	+ static link is available
//	+ but i686(Pentium II) or later CPUs are needed
//
//	[ How to Get ]
//
//	1 : download : libjpeg-turbo-1.5.1-gcc.exe
//	2 : done!
//
//	[ How to Install ]
//
//	1 : install
//	2 : merge "include" and "lib" folders into "MinGW/include" "MinGW/lib" folders
//	3 : done!
//
//	+ don't mix other libjpeg library's header files
//
//	[ How to use : for system ]
//
//	1 : #include <jpeglib.h>
//	2 : done!
//
//	[ How to use : for client ]
//
//	1 : include "nonnon/neutral/jpg.c"
//	2 : done!
//
//	[ How to Link ]
//
//	-ljpeg
//
//	+ "-static" is not needed
//
//	+ "libjpeg.a" is needed in MinGW/lib folder
//	+ "jpeg.lib" is not needed


// [ Mechanism ] : when not using DLL : slower version : currently used in VC++ x64 version
//
//	directly embed
//
//	[ How to use : for system ]
//
//	1 : include "nonnon/floss/libjpeg.c"
//	2 : done!
//
//	[ How to use : for client ]
//
//	1 : #define N_JPG_EMBED
//	2 : include "nonnon/neutral/jpg.c"
//	3 : done!
//
//	[ How to Link ]
//
//	no link needed


// [ Mechanism ] : when not using DLL : faster version : currently used in MinGW version
//
//	http://cetus.sakura.ne.jp/softlab/jpeg-x86simd/jpegsimd.html
//	+ 2x faster than original libjpeg
//
//	+ static link is available
//
//	[ How to Get ]
//
//	1 : download : jpegsrc-6b-x86simd-1.02.zip
//	2 : done!
//
//	[ How to Install ]
//
//	1 : install MinGW MSYS
//	2 : copy : "jpeg-6bx" to "MinGW/msys/1.0/home/[UserName]"
//	3 : run MSYS
//	4 : run "configure --enable-uchar-boolean"
//	5 : copy "libjpeg.a" to "MinGW/lib" folder
//	6 : copy "jpeglib.h" "jconfig.h" "jmorecfg.h" to "MinGW/include" folder
//	7 : done!
//
//	+ don't mix other libjpeg library's header files
//
//	+ "nonnon/_sdk/jpeg-6bx" has compiled "libjpeg.a" and headers
//
//	[ How to use : for system ]
//
//	1 : #include <jpeglib.h>
//	2 : done!
//
//	[ How to use : for client ]
//
//	1 : include "nonnon/neutral/jpg.c"
//	2 : done!
//
//	[ How to Link ]
//
//	-ljpeg




#ifndef _H_NONNON_NEUTRAL_JPG
#define _H_NONNON_NEUTRAL_JPG




#ifdef N_JPG_EMBED

#include "../floss/libjpeg.c"

#else  // #ifdef N_JPG_EMBED

#include <jpeglib.h>

#endif // #ifdef N_JPG_EMBED




#include "./bmp/_codec.c"
#include "./bmp/_error.c"
#include "./bmp.c"
#include "./string.c"




static int n_jpg_quality = 80;




void
n_jpg_swaprgb( n_bmp *bmp )
{

	// [ Mechanism ]
	//
	//	this module also does alpha-clearing
	//	see n_bmp_24bit() for details

	s32 bmpsx = N_BMP_SX( bmp );
	s32 bmpsy = N_BMP_SY( bmp );

	s32 x = 0;
	s32 y = 0;
	while( 1 )
	{

		u32 color;
		n_bmp_ptr_get_fast( bmp, x,y, &color );

		int r = n_bmp_b( color );
		int g = n_bmp_g( color );
		int b = n_bmp_r( color );

		color = n_bmp_rgb( r,g,b );

		n_bmp_ptr_set_fast( bmp, x,y,  color );


		x++;
		if ( x >= bmpsx )
		{

			x = 0;

			y++;
			if ( y >= bmpsy ) { break; }
		}
	}


	return;
}

bool
n_jpg_bmp2jpg( const n_posix_char *jpgname, const n_bmp *bmp_arg )
{

	if ( n_string_is_empty( jpgname ) ) { return true; }

	if ( n_bmp_error( bmp_arg ) ) { return true; }


	n_bmp bmp; n_bmp_carboncopy( bmp_arg, &bmp );
	n_jpg_swaprgb( &bmp );
	n_bmp_24bit  ( &bmp );

	s32 bmpsx = N_BMP_SX( &bmp );
	s32 bmpsy = N_BMP_SY( &bmp );


	struct jpeg_compress_struct jcs;
	struct jpeg_error_mgr       jem;

	jcs.err              = jpeg_std_error( &jem );
	jpeg_create_compress( &jcs );

	FILE *fp = n_posix_fopen_write( jpgname );
	jpeg_stdio_dest     ( &jcs, fp );

	jcs.image_width      = bmpsx;
	jcs.image_height     = bmpsy;
	jcs.input_components = 3;
	jcs.in_color_space   = JCS_RGB;

	jpeg_set_defaults   ( &jcs );
	jpeg_set_quality    ( &jcs, n_jpg_quality, true );
	jpeg_start_compress ( &jcs, true );

	u8      *row_ptr    = (void*) N_BMP_PTR( &bmp );
	JSAMPROW row_pointer[ 1 ];
	s32      row_stride = n_bmp_linebyte( bmpsx, 24 );

	s32 y = 0;
        while( 1 )
	{

		row_pointer[ 0 ] = &row_ptr[ row_stride * ( bmpsy - 1 - y ) ];
		jpeg_write_scanlines( &jcs, row_pointer, 1 );

		y++;
		if ( y >= bmpsy ) { break; }
        }

	jpeg_finish_compress ( &jcs );
	jpeg_destroy_compress( &jcs );


	n_posix_fclose( fp );


	n_bmp_free( &bmp );


	return false;
}

bool
n_jpg_jpg2bmp( const n_posix_char *jpgname, n_bmp *bmp_ret )
{

	if ( n_string_is_empty( jpgname ) ) { return true; }

	if ( bmp_ret == NULL ) { return true; }


	// [!] : sniffer

	FILE *fp = NULL;

	{

		u8 sniffer_jpg[] = { 0xff, 0xd8, 0xff };
		n_posix_structstat_size_t sniffer_byte = 3;

		if ( sniffer_byte > n_posix_stat_size( jpgname ) ) { return true; }

		fp = n_posix_fopen_read( jpgname );
		if ( fp == NULL ) { return true; }

		u8 sniffer_ptr[ 3 ];
		n_posix_fread( sniffer_ptr, sniffer_byte, 1, fp );
	
		if ( false == n_memory_is_same( sniffer_ptr, sniffer_jpg, sniffer_byte ) )
		{
			n_posix_fclose( fp );
			return true;
		}

		// [Needed] : rewind

		n_posix_fseek( fp, 0, SEEK_SET );

	}


	struct jpeg_decompress_struct jds;
	struct jpeg_error_mgr         jem;

	jds.err = jpeg_std_error( &jem );
	jpeg_create_decompress( &jds );


	jpeg_stdio_src        ( &jds, fp );
	jpeg_read_header      ( &jds, true );
	jpeg_start_decompress ( &jds );
//n_posix_debug_literal( " %d ", jds.output_components );
	if (
		( jds.output_components != 1 )
		&&
		( jds.output_components != 3 )
	)
	{
		jpeg_destroy_decompress( &jds );
		n_posix_fclose( fp );
		return true;
	}


	s32 bmpsx = jds.image_width;
	s32 bmpsy = jds.image_height;

	n_bmp_new_fast( bmp_ret, bmpsx, bmpsy );


	u8      *row_ptr    = (void*) N_BMP_PTR( bmp_ret );
	JSAMPROW row_pointer[ 1 ];

	if ( jds.output_components == 1 )
	{

		s32  linebyte = n_bmp_linebyte( bmpsx, 32 );
		s32  scanline = ( bmpsy - 1 ) * linebyte;
		u8  *row_gray = n_memory_new_closed( linebyte );

		row_pointer[ 0 ] = row_gray;

		s32 y = 0;
        	while( 1 )
		{

			jpeg_read_scanlines( &jds, row_pointer, 1 );

			s32 x  = 0;
			s32 xx = 0;
			while( 1 )
			{

				row_ptr[ scanline + xx ] = row_gray[ x ]; xx++;
				row_ptr[ scanline + xx ] = row_gray[ x ]; xx++;
				row_ptr[ scanline + xx ] = row_gray[ x ]; xx++;
				row_ptr[ scanline + xx ] = N_BMP_ALPHA_CHANNEL_VISIBLE; xx++;

				x++;
				if ( x >= bmpsx ) { break; }
			}

			y++;
			if ( y >= bmpsy ) { break; }

			scanline -= linebyte;
        	}

		n_memory_free_closed( row_gray );

	} else
	if ( jds.output_components == 3 )
	{

		s32 row_stride = n_bmp_linebyte( bmpsx, 24 );

		s32 y = 0;
        	while( 1 )
		{

			row_pointer[ 0 ] = &row_ptr[ row_stride * ( bmpsy - 1 - y ) ];
			jpeg_read_scanlines( &jds, row_pointer, 1 );

			y++;
			if ( y >= bmpsy ) { break; }
        	}


		N_BMP_DEPTH  ( bmp_ret ) = 24;
		n_bmp_32bit  ( bmp_ret );
		n_jpg_swaprgb( bmp_ret );

	}

	jpeg_finish_decompress ( &jds );
	jpeg_destroy_decompress( &jds );


	n_posix_fclose( fp );


	return false;
}




#endif // _H_NONNON_NEUTRAL_JPG

