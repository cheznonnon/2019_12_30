// Nonnon Wave
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_NEUTRAL_WAV_SAMPLE
#define _H_NONNON_NEUTRAL_WAV_SAMPLE




#include "./_error.c"


#include "../random.c"




#include <complex.h>




#define N_WAV_2PI ( 2.0 * M_PI )
#define N_WAV_AMP ( SHRT_MAX   )




bool
n_wav_sample_is_accessible( n_wav *wav, size_t i )
{

	if ( n_wav_error_format( wav ) ) { return false; }

	if ( ( i >= 0 )&&( i < wav->count ) ) { return true; }

	return false;
}

void
n_wav_sample_get( n_wav *wav, size_t i, double *l, double *r )
{

	//if ( n_wav_sample_is_accessibile( wav, i ) ) { return; }


	const size_t p = i * N_WAV_STEREO( wav );


	s16 *ptr = (s16*) N_WAV_PTR( wav );


	if ( l != NULL ) { (*l) = (double) ptr[ p + 0 ]; }
	if ( r != NULL ) { (*r) = (double) ptr[ p + 1 ]; }


	return;
}

void
n_wav_sample_set( n_wav *wav, size_t i, double l, double r )
{

	//if ( n_wav_sample_is_accessibile( wav, i ) ) { return; }


	const size_t p = i * N_WAV_STEREO( wav );


	s16 *ptr = (s16*) N_WAV_PTR( wav );


	ptr[ p + 0 ] = (s16) l;
	ptr[ p + 1 ] = (s16) r;


	return;
}

#define n_wav_sample_clamp( n ) n_posix_minmax( SHRT_MIN, SHRT_MAX, n )

void
n_wav_sample_add( n_wav *wav, size_t i, double l, double r )
{

	//if ( n_wav_sample_is_accessibile( wav, i ) ) { return; }


	const size_t p = i * N_WAV_STEREO( wav );


	s16 *ptr = (s16*) N_WAV_PTR( wav );


	ptr[ p + 0 ] = n_wav_sample_clamp( (int) l + ptr[ p + 0 ] );
	ptr[ p + 1 ] = n_wav_sample_clamp( (int) r + ptr[ p + 1 ] );


	return;
}

void
n_wav_sample_mix( n_wav *wav, size_t i, double l, double r, double ratio_l, double ratio_r )
{

	//if ( n_wav_sample_is_accessibile( wav, i ) ) { return; }


	const size_t p = i * N_WAV_STEREO( wav );


	s16 *ptr = (s16*) N_WAV_PTR( wav );


	l *= ratio_l;
	r *= ratio_r;

	l += (double) ptr[ p + 0 ] * ( 1.0 - ratio_l );
	r += (double) ptr[ p + 1 ] * ( 1.0 - ratio_r );


	ptr[ p + 0 ] = (s16) l;
	ptr[ p + 1 ] = (s16) r;


	return;
}

double
n_wav_sample_hz2sample( double hz )
{

	// [!] : cache for performance

	static double p_hz = 0;
	static double ret  = 0;

	if ( p_hz != hz ) { ret = 44100.0 / hz; p_hz = hz; }


	return ret;
}

double
n_wav_sample_cosine( double hz, size_t x )
{

	// [!] : I : <complex.h> complex number

	double t = n_wav_sample_hz2sample( hz );
	double d;

#ifdef _MSC_VER

	d = (double) x / t;
	d = cos( N_WAV_2PI * d );
	d = N_WAV_AMP * d;

#else // #ifdef _MSC_VER

	d = (double) x / t;
	d = cexp( I * ( N_WAV_2PI * d ) );
	d = N_WAV_AMP * d;

#endif // #ifdef _MSC_VER

	return d;
}

double
n_wav_sample_sine_coeff( double hz, size_t x )
{

	double t = n_wav_sample_hz2sample( hz );
	double d;

	d = (double) x / t;
	d = sin( N_WAV_2PI * d );


	return d;
}

double
n_wav_sample_sine( double hz, size_t x )
{

	double d = n_wav_sample_sine_coeff( hz, x );

	d = N_WAV_AMP * d;


	return d;
}

double
n_wav_sample_sawtooth( double hz, size_t x )
{

	// [!] : currently cosine compatible curve will generate

	double t = n_wav_sample_hz2sample( hz );
	double d;

	d = fmod( x, t );
	d = d / t;
	d = N_WAV_AMP * d;
	d = d - ( N_WAV_AMP / 2 );
	d = d * -1;


	return d;
}

double
n_wav_sample_square( double hz, size_t x )
{

	double d = n_wav_sample_sine_coeff( hz, x );

	if ( d > 0 ) { d =  N_WAV_AMP; } else
	if ( d < 0 ) { d = -N_WAV_AMP; }


	return d;
}

double
n_wav_sample_sandstorm( double hz, size_t x )
{

	// [!] : human recognition
	//
	//	20Hz to 20,000Hz

	//double t = n_wav_sample_hz2sample( hz );
	double d = n_wav_sample_sine( n_random_range( (u32) hz ), x );


	return d;
}


#endif // _H_NONNON_NEUTRAL_WAV_SAMPLE

