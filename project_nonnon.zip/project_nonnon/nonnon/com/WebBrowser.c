// Nonnon COM : WebBrowser
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html





#ifndef _H_NONNON_WIN32_COM_WEBBROWSER
#define _H_NONNON_WIN32_COM_WEBBROWSER




#include "./com.c"
#include "./_template/IOleClientSite.c"
//#include "./_template/IStorage.c"

#include "../win32/sysinfo/version_misc.c"
#include "../win32/win.c"

#include "./WebBrowser/IWebBrowser2.c"
#include "./WebBrowser/historycleaner.c"


// [!] : inherit

#define n_WebBrowser_back         n_IWebBrowser2_back
#define n_WebBrowser_next         n_IWebBrowser2_next
#define n_WebBrowser_home         n_IWebBrowser2_home
#define n_WebBrowser_load         n_IWebBrowser2_load
#define n_WebBrowser_stop         n_IWebBrowser2_stop
#define n_WebBrowser_MSHTML       n_IWebBrowser2_MSHTML
#define n_WebBrowser_go           n_IWebBrowser2_go
#define n_WebBrowser_url          n_IWebBrowser2_url
#define n_WebBrowser_title        n_IWebBrowser2_title
#define n_WebBrowser_status       n_IWebBrowser2_status
#define n_WebBrowser_useragent    n_IWebBrowser2_useragent
#define n_WebBrowser_version      n_IWebBrowser2_version
#define n_WebBrowser_wait         n_IWebBrowser2_wait
#define n_WebBrowser_focus        n_IWebBrowser2_focus
#define n_WebBrowser_resize       n_IWebBrowser2_resize
#define n_WebBrowser_exec         n_IWebBrowser2_exec
#define n_WebBrowser_zoom_default n_IWebBrowser2_zoom_default
#define n_WebBrowser_exit         n_IWebBrowser2_exit


#define n_WebBrowser_open(  _this ) n_IWebBrowser2_exec( _this, OLECMDID_OPEN  )
#define n_WebBrowser_find(  _this ) n_IWebBrowser2_exec( _this, OLECMDID_FIND  )
#define n_WebBrowser_copy(  _this ) n_IWebBrowser2_exec( _this, OLECMDID_COPY  )
#define n_WebBrowser_paste( _this ) n_IWebBrowser2_exec( _this, OLECMDID_PASTE )
#define n_WebBrowser_cut(   _this ) n_IWebBrowser2_exec( _this, OLECMDID_CUT   )
#define n_WebBrowser_undo(  _this ) n_IWebBrowser2_exec( _this, OLECMDID_UNDO  )




void
n_WebBrowser_init
(
	IWebBrowser2       **ret_interface,
	DWebBrowserEvents2  *eventsink,
	DWORD               *cookie,
	HWND                *ret_hgui,
	HWND                 hwnd_parent,
	n_posix_char        *url
)
{

	if ( ret_interface == NULL ) { return; }

	*ret_interface = NULL;
	if ( ret_hgui != NULL ) { *ret_hgui = NULL; }


	// [!] : try to make an embeddable object

	IWebBrowser2 *_this = NULL;
/*
	{

		n_IOleInPlaceSite_hwnd = hwnd_parent;

		IOleClientSite *oc = &n_IOleClientSite_instance;
		IStorage       *st = &n_IStorage_instance;


		GUID guid_CLSID_WebBrowser = n_CLSID_WebBrowser;
		GUID guid_IID_IOleObject   = n_IID_IOleObject;

		IOleObject *oo = NULL;
		OleCreate
		(
			&guid_CLSID_WebBrowser,
			&guid_IID_IOleObject,
			OLERENDER_DRAW,
			NULL,
			oc,
			st,
			(void*) &oo
		);

		if ( oo != NULL )
		{

			IOleObject_SetHostNames( oo, L"Web Host", L"Web View" );
			OleSetContainedObject( (void*) oo, TRUE );

			RECT r; GetClientRect( n_IOleInPlaceSite_hwnd, &r );
			HRESULT hr = IOleObject_DoVerb( oo, OLEIVERB_SHOW, NULL, oc, 0, n_IOleInPlaceSite_hwnd, &r );
			if ( FAILED( hr ) ) { n_com_debug_a( "IOleObject_DoVerb()" ); }

			n_com_interface( oo, n_guid_IID_IWebBrowser2, (void*) &_this );

		} else {

			n_com_debug_a( "OleCreate()" );

		}

		n_com_release( oo );

	}
*/

	{

		n_com_class( n_guid_CLSID_WebBrowser, n_guid_IID_IWebBrowser2, (void*) &_this );


		IOleObject *oo  = NULL;
		n_com_interface( _this, n_guid_IID_IOleObject, (void*) &oo );
		if ( oo == NULL )
		{

			n_com_debug_a( "IOleObject" );

			n_com_release( _this );
			_this = NULL;

		} else {

			n_IOleInPlaceSite_hwnd = hwnd_parent;

			IOleClientSite *oc = &n_IOleClientSite_instance;


			// [Mechanism] : 0x00020191
			//
			//	0x00000001 : OLEMISC_RECOMPOSEONRESIZE
			//	0x00000010 : OLEMISC_CANTLINKINSIDE
			//	0x00000080 : OLEMISC_INSIDEOUT
			//	0x00000100 : OLEMISC_ACTIVATEWHENVISIBLE
			//	0x00020000 : OLEMISC_SETCLIENTSITEFIRST

			DWORD olemisc = 0;
			IOleObject_GetMiscStatus( oo, DVASPECT_CONTENT, &olemisc );
//n_posix_debug_literal( "%d : %08x", olemisc, olemisc );
			if ( olemisc & OLEMISC_SETCLIENTSITEFIRST )
			{
				IOleObject_SetClientSite( oo, oc );
			}


			RECT r; GetClientRect( hwnd_parent, &r );

			HRESULT hr = IOleObject_DoVerb( oo, OLEIVERB_INPLACEACTIVATE, NULL, oc, 0, hwnd_parent, &r );
			if ( FAILED( hr ) ) { n_com_debug_a( "IOleObject_DoVerb()" ); }

		}

		n_com_release( oo );

	}


	if ( _this == NULL ) { return; } else { *ret_interface = _this; }


	// [Needed] : Win95 + IE4 : crash prevention : n_WebBrowser_wait()


	// Event Sink

	n_WebBrowser_wait( _this );

	if ( ( eventsink != NULL )&&( cookie != NULL ) )
	{
		n_com_override_init( _this, n_guid_DIID_DWebBrowserEvents2, (void*) eventsink, cookie );
	}


	// First Navigation #1

	{

		BSTR bstr = n_com_bstr_init_literal( "about:blank" );

		// [!] : don't use n_WebBrowser_go()
		//n_WebBrowser_go( _this, bstr );

		IWebBrowser2_Navigate( _this, bstr, NULL, NULL, NULL, NULL );

		n_com_bstr_exit( bstr );

	}


	// Embedding

	n_WebBrowser_wait( _this );

	// [!] : SetParent() is already done by IOleObject_DoVerb()

	HWND hgui = n_win_hwnd_find_literal( hwnd_parent, "Shell Embedding" );

	if ( ret_hgui != NULL ) { *ret_hgui = hgui; }


	// First Navigation #2

	// [x] : all version of IE : the first page will not be registerd in history
	//
	//	when "about:blank" is loaded twice

	if (
		( false == n_string_is_empty( url ) )
		&&
		( false == n_string_is_same_literal( "about:blank", url ) )
	)
	{

		BSTR bstr = n_com_bstr_init( url );

		n_WebBrowser_go( _this, bstr );

		n_com_bstr_exit( bstr );

	} else {

		// [Needed] : prevent redraw error

		n_WebBrowser_wait( _this );

	}


	return;
}

#define n_WebBrowser_cursor2IHTMLElement( p, a ) n_WebBrowser_IHTMLElement( p, a, true )

IHTMLElement*
n_WebBrowser_IHTMLElement( IWebBrowser2 *_this, HWND hgui, bool is_hovered )
{

	// [!] : this module may return NULL in some cases


	if ( _this == NULL ) { return NULL; }


	// [Patch] : IE6 : IHTMLEventObj is not visible in some cases
	//
	//	1 : IWebBrowser2_get_Document()       => IHTMLDocument2
	//	2 : IHTMLDocument2_get_parentWindow() => IHTMLWindow2
	//	3 : IHTMLWindow2_get_event()          => IHTMLEventObj
	//	4 : IHTMLEventObj_get_srcElement()    => IHTMLElement

	IHTMLDocument2 *d2 = n_WebBrowser_MSHTML( _this );
	if ( d2 == NULL ) { return NULL; }


	IHTMLWindow2  *w2 = NULL;
	IHTMLEventObj *eo = NULL;
	IHTMLElement  *el = NULL;


	if ( is_hovered )
	{

		IHTMLDocument2_get_parentWindow( d2, &w2 );

		if ( w2 != NULL ) { IHTMLWindow2_get_event      ( w2, &eo ); }
		if ( eo != NULL ) { IHTMLEventObj_get_srcElement( eo, &el ); }

		// [!] : fallback

		if ( el == NULL )
		{
			s32 x,y; n_win_cursor_position_relative( hgui, &x,&y );
			IHTMLDocument2_elementFromPoint( d2, x,y, &el );
		}

	} else {

		IHTMLDocument2_get_activeElement( d2, &el );

	}


	// [!] : don't release "el"

	n_com_release( eo );
	n_com_release( w2 );
	n_com_release( d2 );


	return el;
}

#define n_WebBrowser_cursor2tagname( p, a ) n_WebBrowser_tag( p, a, true )

BSTR
n_WebBrowser_tag( IWebBrowser2 *_this, HWND hgui, bool is_hovered )
{

	// [!] : you need to do n_com_bstr_exit() with returned BSTR


	BSTR bstr = NULL;


	IHTMLElement *el = n_WebBrowser_IHTMLElement( _this, hgui, is_hovered );
	if ( el != NULL )
	{
		IHTMLElement_get_tagName( el, &bstr );
	}

	n_com_release( el );


	// [!] : wcscmp() will crash when NULL

	if ( bstr == NULL ) { bstr = n_com_bstr_init_literal( "" ); }


//n_com_debug_w( bstr );
	return bstr;
}

bool
n_WebBrowser_tag_is_same( IWebBrowser2 *_this, HWND hgui, const wchar_t *wstr )
{

	// [!] : wcscmp() will crash when NULL

	if ( wstr == NULL ) { return false; }


	bool ret = false;


	BSTR bstr = n_WebBrowser_tag( _this, hgui, false );
//MessageBoxW( NULL, bstr, L"DEBUG", 0 );

	if ( 0 == wcscmp( bstr, wstr ) ) { ret = true; }

	n_com_bstr_exit( bstr );


	return ret;
}

#define n_WebBrowser_cursor2anchor( p, a ) n_WebBrowser_anchor( p, a, true )

BSTR
n_WebBrowser_anchor( IWebBrowser2 *_this, HWND hgui, bool is_hovered )
{

	// [!] : you need to do n_com_bstr_exit() with returned BSTR

	// [x] : Security : empty string will navigate to MSN Search


	IHTMLElement *el  = n_WebBrowser_IHTMLElement( _this, hgui, is_hovered );
	BSTR          tag = n_WebBrowser_tag         ( _this, hgui, is_hovered );


	VARIANT v;

	if ( 0 == wcscmp( tag, L"A" ) )
	{
		if ( el != NULL ) { IHTMLElement_getAttribute( el, L"href", 2 | 4, &v ); }
	} else {
		V_BSTR( &v ) = n_com_bstr_init_literal( "about:blank" );
	}
//n_com_debug_w( V_BSTR( &v ) );


	n_com_bstr_exit( tag );
	n_com_release( el );


	// [!] : wcscmp() will crash when NULL

	BSTR bstr = V_BSTR( &v );
	if ( bstr == NULL ) { bstr = n_com_bstr_init_literal( "" ); }


	return bstr;
}

BSTR
n_WebBrowser_selection( IWebBrowser2 *_this )
{

	// [!] : you need to do n_com_bstr_exit() with returned BSTR


	BSTR bstr = NULL;


	IHTMLDocument2       *d2 = n_WebBrowser_MSHTML( _this );
	IHTMLSelectionObject *so = NULL; if ( d2 != NULL ) { IHTMLDocument2_get_selection( d2, &so ); }
	IHTMLTxtRange        *tr = NULL; if ( so != NULL ) { IHTMLSelectionObject_createRange( so, (void*) &tr ); }

	if ( tr != NULL ) { IHTMLTxtRange_get_text( tr, &bstr ); }

	n_com_release( tr );
	n_com_release( so );
	n_com_release( d2 );


	if ( bstr == NULL ) { bstr = n_com_bstr_init_literal( "" ); }


//n_com_debug_w( bstr );
	return bstr;
}

void
n_WebBrowser_selection_debug( IWebBrowser2 *_this )
{

	BSTR bstr = n_WebBrowser_selection( _this );

	{

		n_posix_char *s = n_com_bstr2string( bstr );

		n_posix_debug( s );

		n_memory_free( s );

	}

	n_com_bstr_exit( bstr );


	return;
}

bool
n_WebBrowser_is_editable( IWebBrowser2 *_this, HWND hgui )
{

	// [x] : this module misbehaves with frameset


	bool ret = false;


	// [x] : this code is flaky : VARIANT_TRUE is returned frequently
/*
	IHTMLElement *el = n_WebBrowser_IHTMLElement( _this, hgui, false );

	if ( el != NULL )
	{

		VARIANT_BOOL b = VARIANT_FALSE;
		HRESULT hret = IHTMLElement_isTextEdit( el, &b );
		if ( FAILED( hret ) ) { n_posix_debug( L"" ); }

		ret = ( b != VARIANT_FALSE );

	}

	n_com_release( el );
*/


	if ( n_WebBrowser_tag_is_same( _this, hgui, L"INPUT"    ) ) { ret = true; } else
	if ( n_WebBrowser_tag_is_same( _this, hgui, L"TEXTAREA" ) ) { ret = true; }


	return ret;
}

int
n_WebBrowser_event_mousebutton( IWebBrowser2 *_this )
{

	// [Mechanism]
	//
	//	use in the dispatch event like HTMLDocumentEvents
	//	some DISPID_*s doesn't support this
	//
	//	[ precise reference is missing ]
	//
	//	search MSDN like onmousedown with DISPID_MOUSEDOWN
	//	"DHTML Event" has some hits


	if ( _this == NULL ) { return 0; }


	IHTMLDocument2 *d2 = n_WebBrowser_MSHTML( _this );
	IHTMLWindow2   *w2 = NULL; if ( d2 != NULL ) { IHTMLDocument2_get_parentWindow( d2, &w2 ); }
	IHTMLEventObj  *eo = NULL; if ( w2 != NULL ) { IHTMLWindow2_get_event         ( w2, &eo ); }
	long             l =    0; if ( eo != NULL ) { IHTMLEventObj_get_button       ( eo, &l  ); }

	n_com_release( eo );
	n_com_release( w2 );
	n_com_release( d2 );


	int mk = 0;
	if ( l & 1 ) { mk |= MK_LBUTTON; }
	if ( l & 2 ) { mk |= MK_RBUTTON; }
	if ( l & 4 ) { mk |= MK_MBUTTON; }


	// [Patch] : "l" will be zero when...
	//
	//	Frameset
	//	Events which don't support "button" property

	if ( n_win_is_input( VK_LBUTTON ) ) { mk |= MK_LBUTTON; }
	if ( n_win_is_input( VK_MBUTTON ) ) { mk |= MK_MBUTTON; }
	if ( n_win_is_input( VK_RBUTTON ) ) { mk |= MK_RBUTTON; }


	return mk;
}

void
n_WebBrowser_on_keydown( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, IWebBrowser2 *wb, HWND hgui )
{

	if ( wb == NULL ) { return; }


	if ( msg != WM_KEYDOWN ) { return; }


	int  ver   = n_WebBrowser_version();
	int  vk    = (int) wparam;
	bool ctrl  = n_win_is_input( VK_CONTROL );
	bool edit  = n_WebBrowser_is_editable( wb, hgui );
	bool frame = n_WebBrowser_tag_is_same( wb, hgui, L"FRAME" );

	if ( ver >= 4 )
	{
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hgui ), "Keybind" );

		if ( vk == VK_F5 ) { n_WebBrowser_load( wb ); }

		if ( ( ctrl )&&( vk == 'C' ) ) { n_WebBrowser_copy ( wb ); }
		if ( ( ctrl )&&( vk == 'F' ) ) { n_WebBrowser_find ( wb ); }

		if ( edit )
		{
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hgui ), "Editable" );

			if ( ( ctrl )&&( vk == 'V' ) ) { n_WebBrowser_paste( wb ); }
			if ( ( ctrl )&&( vk == 'X' ) ) { n_WebBrowser_cut  ( wb ); }
			if ( ( ctrl )&&( vk == 'Z' ) ) { n_WebBrowser_undo ( wb ); }

		} else
		if ( frame == false )
		{
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hgui ), "Not A Frame" );

			if ( vk == VK_BACK ) { n_WebBrowser_back( wb ); }

		}

	}

	if ( ver >= 8 )
	{
		if ( ( ctrl )&&( vk == 'O' ) ) { n_WebBrowser_open ( wb ); }
	}


	return;
}


#endif // _H_NONNON_WIN32_COM_WEBBROWSER

