// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// internal
void
n_win_txtbox_draw_box( n_win_txtbox *p, HDC hdc, RECT *rect, COLORREF color )
{

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{

		s32 x,y,sx,sy; n_win_rect_expand_size( rect, &x, &y, &sx, &sy );

		if ( color == p->color_back_selected )
		{
			// [!] : for contour
			 x -= p->scale;
			sx += p->scale * 2;
		}

		int a = 222; if ( color == 0 ) { a = 0; }
		int r = GetRValue( color );
		int g = GetGValue( color );
		int b = GetBValue( color );

		n_bmp_box( &n_gdi_doublebuffer_32bpp_instance.bmp, x,y,sx,sy, n_bmp_argb( a,r,g,b ) );

	} else {

		n_win_box( NULL, hdc, rect, color );

	}


	return;
}

// internal
void
n_win_txtbox_draw_text( n_win_txtbox *p, const n_posix_char *str, int cch, RECT *rect, int dt )
{

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{

#ifdef UNICODE
		n_posix_char *s = n_string_carboncopy ( str );
#else  // #ifdef UNICODE
		     wchar_t *s = n_posix_ansi2unicode( str ); cch = -1;
#endif // #ifdef UNICODE


		//p->uxtheme.DrawThemeText( p->uxtheme.htheme, p->hdc, 0,0, s,cch, dt,0, rect );

		{

			// [!] : Win8 or later : effect will be ignored

			DTTOPTS dttopts; ZeroMemory( &dttopts, sizeof( DTTOPTS ) );

			dttopts.dwSize  = sizeof( DTTOPTS );
			dttopts.dwFlags = DTT_COMPOSITED;

			dttopts.dwFlags = dttopts.dwFlags | DTT_TEXTCOLOR;
			dttopts.crText  = p->color___dwm_contour;

			s32 x = -p->scale;
			s32 y = -p->scale;
			while( 1 )
			{//break;

				if ( ( x == 0 )&&( y == 0 ) )
				{
					//
				} else {
					RECT r = { rect->left + x, rect->top + y, rect->right + x, rect->bottom + y };
					p->uxtheme.DrawThemeTextEx( p->uxtheme.htheme, p->hdc, 0,0, s,cch, dt, &r, &dttopts );
				}

				x++;
				if ( x > p->scale )
				{
					x = -p->scale;

					y++;
					if ( y > p->scale ) { break; }
				}
			}

			dttopts.crText = p->color___dwm_textclr;

			p->uxtheme.DrawThemeTextEx( p->uxtheme.htheme, p->hdc, 0,0, s,cch, dt, rect, &dttopts );

		}


		n_string_free( s );

	} else {

		DrawText( p->hdc, str, cch, rect, dt );

	}


	return;
}

void
n_win_txtbox_draw_border( n_win_txtbox *p, bool is_flat )
{

	COLORREF outer = p->color_border___flat;
	if ( n_win_is_hovered( p->hwnd ) ) { outer = p->color_base_selected; }

	s32 sx,sy; n_win_size_client( p->hwnd, &sx, &sy );

	int i = 0;
	while( 1 )
	{

		n_win_txtbox_frame( p->hdc, i,i,sx-(i*2),sy-(i*2), outer );

		i++;
		if ( i >= p->scale ) { break; }
	}

	if ( is_flat ) { return; }

	while( 1 )
	{//break;


		n_win_txtbox_frame( p->hdc, i,i,sx-(i*2),sy-(i*2), p->color_back__enabled );

		i++;
		if ( i >= ( p->scale * 2 ) ) { break; }
	}


	return;
}

// internal
void
n_win_txtbox_draw_debug_fastmode( n_win_txtbox *p, s32 y )
{

	if ( p      == NULL ) { return; }
	if ( p->hdc == NULL ) { return; }


	const n_posix_char *str = n_posix_literal( "!" );


	SetBkColor  ( p->hdc, RGB( 255,255,255 ) );
	SetTextColor( p->hdc, RGB(   0,200,255 ) );

	s32 osx = 0;
	if (
		( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		&&
		( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
	)
	{
		osx = p->number_pxl_sx + p->number_pad_pxl_sx;
	}

	SIZE size = n_win_txtbox_size_text_fast( p, p->hdc, str );
	RECT rect = n_win_rect_set( NULL, p->pad_pxl_sx + osx, y, size.cx, size.cy );

	n_win_txtbox_draw_text( p, str, -1, &rect, p->drawtext_modes );


	return;
}

// internal
void
n_win_txtbox_draw_eol( n_win_txtbox *p, s32 x, s32 y, u32 bg, n_posix_char *eol )
{

	if ( p      == NULL ) { return; }
	if ( p->hdc == NULL ) { return; }


	SetBkColor  ( p->hdc, bg );
	SetTextColor( p->hdc, p->color_text_eol_mark );

	SIZE size = n_win_txtbox_size_text_fast( p, p->hdc, eol );
	RECT rect = n_win_rect_set( NULL, x, y, size.cx, size.cy );

	n_win_txtbox_draw_text( p, eol, -1, &rect, p->drawtext_modes );


	return;
}

// internal
void
n_win_txtbox_draw_caret( n_win_txtbox *p )
{

	// [!] : fake caret

	// [x] : system caret is buggy
	//
	//	interfere with other edit controls' caret


	if ( p      == NULL ) { return; }
	if ( p->hdc == NULL ) { return; }


	s32  x = p->caret_pxl_x;
	s32  y = p->caret_pxl_y;
	s32 sx = p->caret_pxl_sx;
	s32 sy = p->caret_pxl_sy;
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", x, y );


	// [!] : Win9x/NT4        : "sx" is 2px
	// [!] : Win2000 or later : "sx" is 1px by default (you can change this)

	if ( p->is_2k_or_later )
	{
		if ( ( p->ime_onoff )&&( sx == 1 ) ) { sx = 2; }
	} else {
		//
	}


	// Debug Center

	//sx = 10;


	if ( ( p->caret_onoff )||( p->input_onoff ) )
	{

		bool draw = true;

		u32 color = p->color_caret_focused;
		if ( p->hwnd != GetFocus() )
		{
			color = p->color_caret_nofocus;

			if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_NOCARET )
			{
				draw = false;
			}
		}

		if ( draw )
		{

			//RECT r; n_win_rect_set( &r, x, y, sx,sy );
			//n_win_txtbox_draw_box( p, p->hdc, &r, color );

			COLORREF fg = color;
			COLORREF bg = p->color_text_backgrnd;

			n_win_txtbox_box_invert( p->hdc, x,y, sx,sy, fg, bg );

		}


	}


	// [!] : remember the last position

	POINT pt = { x, y }; p->ime = pt;


	return;
}

// internal
void
n_win_txtbox_draw_linenumber( n_win_txtbox *p, size_t text_y, s32 x, s32 y, s32 sx, s32 sy )
{

	if ( false == ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM ) ) { return; }


	RECT rect = n_win_rect_set( NULL, p->pad_pxl_sx, y, p->number_pxl_sx, sy );

	if ( text_y < p->txt.sy )
	{
		int cch_y = 1 + text_y;

		bool over_ten_thousand = false;
		if ( cch_y >= 10000 ) { over_ten_thousand = true; }

		if ( cch_y >= 10000 ) { cch_y = cch_y % 10000; }

		n_posix_char str[ 6 + 1 ];

		// [Patch] : not working accurately

		if ( cch_y < 1000 )
		{
			if ( over_ten_thousand )
			{
				n_posix_sprintf_literal( str, " %04d ", cch_y );
			} else {
				n_posix_sprintf_literal( str, " % 4d ", cch_y );
			}
		} else {
			n_posix_sprintf_literal( str, " %d "  , cch_y );
		}

		COLORREF bg = p->color_back_linenum1;
		COLORREF fg = p->color_text_linenum1;

//if ( text_y == 0 ) { n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->select_cch_sx, p->select_cch_sy ); }

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->select_cch_sx, p->select_cch_sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->line_min_onoff, p->line_max_onoff );

		bool is_curline = false;

		if (
			( ( p->line_min_onoff )&&( text_y == ( p->select_cch_y + p->select_cch_sy - 1 ) ) )
			||
			( ( p->line_max_onoff )&&( text_y ==   p->select_cch_y                          ) )
			||
			(
				( ( p->line_min_onoff == false )&&( p->line_max_onoff == false ) )
				&&
				( text_y == p->select_cch_y )
			)
		)
		{
			is_curline = true;
			bg = p->color_back_linenum2;
		}

		bool is_sel_line = false;

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->empty_line_selection, p->select_cch_y );

		if (
			(
				( p->empty_line_selection != N_WIN_TXTBOX_NOT_SELECTED )
				&&
				( p->empty_line_selection == p->select_cch_y )
				&&
				( text_y == p->select_cch_y )
			)
			||
			(
				(                1 != p->txt.sy )
				&&
				( p->select_cch_sy == p->txt.sy )
			)
			||
			( ( p->line_min_onoff     )&&( text_y == p->select_cch_y ) )
			||
			( ( p->line_max_onoff     )&&( text_y == p->select_cch_y ) )
			||
			( ( p->select_cch_sx != 0 )&&( text_y == p->select_cch_y ) )
			||
			( n_win_txtbox_is_highlighted( p, -1, text_y ) )
		)
		{
			is_sel_line = true;
			bg = p->color_back_linenum2;
		}

		n_win_txtbox_draw_box( p, p->hdc, &rect, bg );

		if ( ( is_curline )||( is_sel_line ) )
		{
			RECT r = rect; n_win_rect_move( &r, 1, 1 );
			SetTextColor( p->hdc, p->color_back_noselect );
			n_win_txtbox_draw_text( p, str, 6, &r, p->drawtext_modes );

			fg = p->color_text_linenum2;
		}

		SetTextColor( p->hdc, fg );
		n_win_txtbox_draw_text( p, str, 6, &rect, p->drawtext_modes );

		if ( is_sel_line )
		{
			s32 fx = p->pad_pxl_sx + p->number_pxl_sx - ( p->number_pad_pxl_sx / 2 );
			RECT rect = n_win_rect_set( NULL, fx, y, p->number_pad_pxl_sx, sy );
			n_win_txtbox_draw_box( p, p->hdc, &rect, p->color_back_linenum3 );
		}

	} else {

		rect.right++;
		n_win_txtbox_draw_box( p, p->hdc, &rect, p->color_back_linenum1 );

	}

	// [Needed] : padding between line number and text
	{
		COLORREF color = p->color_back_noselect;
		if ( p->debug_onoff ) { color = RGB( 0,255,0 ); }

		RECT rect = n_win_rect_set( NULL, p->pad_pxl_sx + p->number_pxl_sx, y, p->pad_pxl_sx, sy );
		n_win_txtbox_draw_box( p, p->hdc, &rect, color );
	}


	return;
}

// internal
void
n_win_txtbox_draw_singleline( n_win_txtbox *p, s32 text_y, s32 x, s32 y, s32 sx, s32 sy )
{
//return;

	if ( p      == NULL ) { return; }
	if ( p->hdc == NULL ) { return; }


	if ( text_y < ( p->scroll_cch_tabbed_y                         ) ) { return; }
	if ( text_y > ( p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy ) ) { return; }


//if ( p->debug_onoff ) { return; }


	int p_bkmode = GetBkMode( p->hdc );
	SetBkMode( p->hdc, TRANSPARENT );


	bool editbox = ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX );


	// [!] : Stripe Background

	COLORREF bg = p->color_back_noselect;

	if ( p->style & N_WIN_TXTBOX_STYLE_STRIPED )
	{
		if ( text_y & 1 ) { bg = p->color_back_striping; }
	}
//bg = RGB( 200,200,200 );

	p->color_text_backgrnd = bg;


	// [!] : Global Background

	{

		COLORREF color;
		if (
			( editbox == false )
			&&
			( n_win_txtbox_is_highlighted( p, 0, text_y ) )
		)
		{
			color = p->color_back_selected;
//n_win_txtbox_hwndprintf_literal( p, " %d ", text_y );
		} else {
			color = bg;
			if ( p->debug_onoff ) { color = RGB( 222,222,255 ); }
		}
//if ( color ) {}

		if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
		{ 
			color = 0;
		}

//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", y, sy, p->client_pxl_sy );

		s32 tx,ty,tsx,tsy;
		if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		{
			 tx = p->border_pxl_sx;
			 ty = p->border_pxl_sy;
			tsx = p->client_pxl_sx - ( p->border_pxl_sx * 2 );
			tsy = p->client_pxl_sy - ( p->border_pxl_sy * 2 );
		} else {
			 tx = p->border_pxl_sx;
			 ty = y;
			tsx = p->client_pxl_sx - ( p->border_pxl_sx * 2 );
			tsy = sy;
		}

		RECT rect = n_win_rect_set( NULL, tx, ty, tsx, tsy );
		n_win_txtbox_draw_box( p, p->hdc, &rect, color );

	}


	bool tab_onoff = ( false == n_string_is_empty( p->tab_mark ) );
	bool eol_onoff = ( false == n_string_is_empty( p->eol_mark ) );


	bool tab_auto = false;

	if ( tab_onoff )
	{
		tab_auto = n_string_is_same_literal( "auto", p->tab_mark );
	}


	bool          eol_auto = false;
	n_posix_char *eol_str  = N_STRING_EMPTY;

	if ( eol_onoff )
	{
		eol_auto = n_string_is_same_literal( "auto", p->eol_mark );
		if ( eol_auto )
		{
#ifdef UNICODE
			eol_str = n_posix_literal( "\x21a9" );
#else  // #ifdef UNICODE
			eol_str = n_posix_literal( "<" );
#endif // #ifdef UNICODE
		} else {
			eol_str = p->eol_mark;
		}
	}


	n_posix_char *text = n_txt_get( &p->txt, text_y );
//n_win_txtbox_hwndprintf_literal( p, " %s ", text ); return;

	bool  bold_onoff = false;
	HFONT bold_hfont =  NULL;
	if (
		( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
		&&
		( p->style_option & N_WIN_TXTBOX_OPTION_LISTBOX_BOLDTXT )
	)
	{
		if ( n_string_match_literal( text, "[b]" ) )
		{
			bold_onoff = true;

			text = &text[ 3 ];

			bold_hfont = SelectObject( p->hdc, n_win_txtbox_font_bold( n_win_font_get( p->hwnd ) ) );
		}
	}


	// Fast Mode

	int  text_cch           = 0;
	int  text_sx            = 0;
	bool text_tab_is_exist  = false;
	bool text_fastmode      = false;
	bool text_surrogatepair = false;

	n_win_txtbox_tab2space
	(
		 p, text,
		 p->tabstop,
		&text_cch, &text_sx,
		&text_tab_is_exist,
		&text_fastmode,
		&text_surrogatepair,
		 false
	);


	bool outer   = ( ( text_y < p->select_cch_y )||( text_y > ( p->select_cch_y + p->select_cch_sy - 1 ) ) );
	bool inner   = ( ( text_y > p->select_cch_y )&&( text_y < ( p->select_cch_y + p->select_cch_sy - 1 ) ) );
	bool just    = ( ( text_y == p->select_cch_y )&&( p->select_cch_sy == 1 ) );
	bool zeroall = ( ( p->select_cch_sx == 0 )||( p->select_cch_sx == text_cch ) );
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", text_cch, text_sx, just );
//n_posix_debug_literal( "%s\n%s", text, n_txt_get( &p->txt_undo, 0 ) );


	if (
//( false )&&
		( false == ( p->style_option & N_WIN_TXTBOX_OPTION_ALWAYS_SLOWMODE ) )
		&&
		( editbox == false )
		&&
		( text_tab_is_exist == false )
	)
	{
//n_win_txtbox_hwndprintf_literal( p, " 1 : LISTBOX : Proportional Font " );

		n_posix_char *text_tab = n_win_txtbox_tab2space( p, text, p->tabstop, &text_cch,&text_sx, NULL,NULL,NULL, true );


		s32  pxl_x  = p->border_pxl_sx + p->virtual_padding_pxl_sx + p->pad_pxl_sx;
		s32  pxl_sx = p->client_pxl_sx;
		RECT rect   = n_win_rect_set( NULL, pxl_x, y, pxl_sx, sy );


		if ( ( just )&&( p->select_cch_sx != 0 ) )
		{
			SetTextColor( p->hdc, p->color_text_selected );
		} else {
			SetTextColor( p->hdc, p->color_text_noselect );
		}

		n_win_txtbox_draw_text( p, text,-1, &rect, p->drawtext_modes );

		n_memory_free( text_tab );


		if ( bold_onoff ) { n_win_font_exit( SelectObject( p->hdc, bold_hfont ) ); }


		SetBkMode( p->hdc, p_bkmode );

		return;

	} else
	if (
//( false )&&
		( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		&&
		( false == n_string_is_empty( p->placeholder ) )
		&&
		( n_string_is_empty( text ) )
		&&
		( p->hwnd != GetFocus() )
	)
	{
//n_win_txtbox_hwndprintf_literal( p, " 2 : ONELINE : Place Holder " );

		s32 pxl_x  = x;
		s32 pxl_sx = sx;

		SIZE size = n_win_txtbox_size_text( p, p->placeholder );
		if ( p->canvas_real_pxl_sx > size.cx )
		{
			pxl_x = ( p->canvas_real_pxl_sx - size.cx ) / 2;
		}

		SetTextColor( p->hdc, p->color___placeholder );

		RECT rect = n_win_rect_set( NULL, pxl_x, y, pxl_sx, sy );

		n_win_txtbox_draw_text( p, p->placeholder,-1, &rect, p->drawtext_modes );

		SetBkMode( p->hdc, p_bkmode );

		return;

	} else
	if (
//( false )&&
		( p->style        & N_WIN_TXTBOX_STYLE_ONELINE          )
		&&
		( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_LNCACHE )
		&&
		( p->prv_sel_x  == p->select_cch_x  )
		&&
		( p->prv_sel_sx == p->select_cch_sx )
		&&
		( false == n_bmp_error( &p->prv_bmp ) )
	)
	{
//n_win_txtbox_hwndprintf_literal( p, " 3 : ONELINE : Cache Hit " );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->select_cch_sx, p->prv_sel_sx );

		n_bmp *bmp = &n_gdi_doublebuffer_32bpp_instance.bmp;

		s32 _sx = N_BMP_SX( &p->prv_bmp );
		s32 _sy = N_BMP_SY( &p->prv_bmp );
		s32 __x = 0;
		s32 __y = 0;

		if ( false == ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR ) )
		{
			__x = p->pad_pxl_sx - p->border_pxl_sx;
		}

		if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_HCENTER )
		{
			__x = ( sx - _sx ) / 2;
			__y = ( sy - _sy ) / 2;
		}
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", sx, _sx );

		n_bmp_fastcopy( &p->prv_bmp, bmp, 0,0,_sx,_sy, __x,__y );

		SetBkMode( p->hdc, p_bkmode );

		return;

	} else
	if (
//( false )&&
		( editbox )
		&&
		(
			(
				( p->is_font_monospace )
				&&
				( text_tab_is_exist == false )
				&&
				( text_fastmode )
				&&
				( text_surrogatepair == false )
				&&
				( text_cch == text_sx )
				&&
				( ( outer )||( inner )||( ( just )&&( zeroall ) ) )
				&&
				( false == ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_HCENTER ) )
			)
			||
			(
				(
					( just == false )
					||
					( p->hwnd != GetFocus() )
				)
				&&
				( n_win_txtbox_is_right2left_string( text ) )
			)
		)
	)
	{
//n_win_txtbox_hwndprintf_literal( p, " 4 " );
//n_win_txtbox_debug_count( p );
//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d ", just, p->select_cch_sx, text_cch );


		// Line Number

		n_win_txtbox_draw_linenumber( p, text_y, x,y,sx,sy );


		n_posix_char *text_tab = n_win_txtbox_tab2space( p, text, p->tabstop, &text_cch,&text_sx, NULL,NULL,NULL, true );


		s32 pxl_x  = n_win_txtbox_horizontal_centering( p ); if ( pxl_x == 0 ) { pxl_x = x; }
		s32 pxl_sx = sx + p->scroll_pxl_tabbed_x;


		if ( p->scroll_pxl_tabbed_x != 0 )
		{
			s32 linenum_osx = 0;
			if (
				( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
				&&
				( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
			)
			{
				linenum_osx = p->number_pxl_sx + p->number_pad_pxl_sx;
			}
			pxl_x = n_posix_max_s32( p->pad_pxl_sx + linenum_osx, x );
		}

//n_win_txtbox_hwndprintf_literal( p, " %d ", p->select_cch_sx );


		// [x] : TabbedTextOut() : width will be different from space character

		int cch = text_cch - ( p->scroll_pxl_tabbed_x / p->font_pxl_sx );

//n_win_txtbox_hwndprintf_literal( p, " %d ", cch );

		if ( cch > 0 )
		{

//n_win_txtbox_hwndprintf_literal( p, " %s : %d ", str, cch );

			if ( n_win_txtbox_is_highlighted( p, 0, text_y ) )
			{
//n_win_txtbox_hwndprintf_literal( p, " %d ", pxl_x - 1 );
				RECT rect = n_win_rect_set( NULL, pxl_x, y, ( cch * p->font_pxl_sx ), sy );
				n_win_txtbox_draw_box( p, p->hdc, &rect, p->color_back_selected );
			}

			{

				if ( ( inner )||( ( just )&&( p->select_cch_sx != 0 ) ) )
				{
					SetTextColor( p->hdc, p->color_text_selected );
				} else
				if ( ( outer )||( ( just )&&( p->select_cch_sx == 0 ) ) )
				{
					SetTextColor( p->hdc, p->color_text_noselect );
				}

				n_posix_char *str = &text_tab[ p->scroll_pxl_tabbed_x / p->font_pxl_sx ];

				RECT rect = n_win_rect_set( NULL, pxl_x, y, pxl_sx, sy );
				n_win_txtbox_draw_text( p, str,cch, &rect, p->drawtext_modes );

			}

		}


		// Caret

		if ( just )
		{

			s32 ox = p->pad_pxl_sx;
			s32 oy = p->pad_pxl_sy;

			if (
				( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
				&&
				( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
			)
			{
				ox += p->number_pxl_sx + p->number_pad_pxl_sx;
			}

			s32 tx = p->select_cch_x * p->font_pxl_sx;
			if ( p->select_cch_sx != 0 ) { tx = text_cch * p->font_pxl_sx; }

			p->caret_pxl_x = ox + (              tx - p->scroll_pxl_tabbed_x )                 ;
			p->caret_pxl_y = oy + ( p->select_cch_y - p->scroll_cch_tabbed_y ) * p->cell_pxl_sy;

			n_win_txtbox_draw_caret( p );

		}

		// End-Of-Line Marker

		if ( ( eol_onoff )&&( cch >= 0 )&&( (u32) text_y < p->txt.sy ) )
		{
			n_posix_char *str = &text_tab[ p->scroll_pxl_tabbed_x / p->font_pxl_sx ];

			SIZE size; GetTextExtentPoint32( p->hdc, str, cch, &size );
			s32  ox    = p->pad_pxl_sx + size.cx;

			if (
				( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
				&&
				( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
			)
			{
				ox += p->number_pxl_sx + p->number_pad_pxl_sx;
				ox++;
			}

			n_win_txtbox_draw_eol( p, ox, y, bg, eol_str );
		}


		n_memory_free( text_tab );


		// Debug

		//n_win_txtbox_draw_debug_fastmode( p, y );


		if ( bold_onoff ) { n_win_font_exit( SelectObject( p->hdc, bold_hfont ) ); }


		SetBkMode( p->hdc, p_bkmode );

		return;
	}


	// Slow Mode
	//
	//	+ tabstop support
	//	+ CJK fixed pitch patch

//n_win_txtbox_hwndprintf_literal( p, " Slow Mode " );

	SIZE size     = { 0,0 };
	s32  cch      = 0;
	s32  tab      = 0;

	s32  caret_fx = -1;
	s32  caret_tx = -1;
	s32  text_x   =  0;
	s32  tail_x   =  0;
	s32  horz_x   = n_win_txtbox_horizontal_centering( p );

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{
		//horz_x++;
	}

	if (
		( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		&&
		( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
	)
	{
		tail_x = p->pad_pxl_sx + p->number_pxl_sx + p->number_pad_pxl_sx;
	} else {
		tail_x = p->pad_pxl_sx;
	}

	tail_x += p->virtual_padding_pxl_sx;

	tail_x -= p->scroll_pxl_tabbed_x;
	tail_x += horz_x;

	p->oneline_cache_f = tail_x;

	s32 ctl_sy; n_win_size_client( p->hwnd, NULL, &ctl_sy );

	while( 1 )
	{//break;

		n_posix_char *character = n_win_txtbox_character( p, text, text_x, &size, &cch, &tab );

		if ( n_string_is_empty( character ) )
		{

			if ( caret_fx == -1 ) { caret_fx = tail_x; }
			if ( caret_tx == -1 ) { caret_tx = tail_x; }

			break;

		}


		// [!] : DrawText() will be slowdown without manual clipping

		bool is_highlighted = n_win_txtbox_is_highlighted( p, text_x, text_y );
//n_win_txtbox_hwndprintf_literal( p, " %d ", is_highlighted );

		if ( is_highlighted )
		{
			SetTextColor( p->hdc, p->color_text_selected );
		} else {
			SetTextColor( p->hdc, p->color_text_noselect );
		}
//if ( color_bg ) {}
//size.cx *= 2;

		{
			RECT rect = n_win_rect_set( NULL, tail_x, y, size.cx, p->cell_pxl_sy );

			if ( is_highlighted )
			{
				// [x] : ExcludeClipRect() is not working when you use n_bmp_*() functions

				//n_win_txtbox_box( tail_x, y, size.cx, p->cell_pxl_sy, p->color_back_selected );

				s32 tx,ty,tsx,tsy;
				if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
				{
					 tx = tail_x;
					 ty = p->caret_pxl_y;
					tsx = size.cx;
					tsy = p->caret_pxl_sy;
				} else {
					 tx = tail_x;
					 ty = y;
					tsx = size.cx;
					tsy = p->cell_pxl_sy;
				}

				RECT rect = n_win_rect_set( NULL, tx, ty, tsx, tsy );

				n_win_txtbox_draw_box( p, p->hdc, &rect, p->color_back_selected );
			}

			if ( tab_onoff )
			{
				if ( text[ text_x ] == N_STRING_CHAR_TAB )
				{
					if ( tab_auto )
					{
						RECT rect = n_win_rect_set( NULL, tail_x, y, 1, size.cy );
						n_win_txtbox_draw_box( p, p->hdc, &rect, p->color_text_tab_mark );
					} else {
						SetTextColor( p->hdc, p->color_text_tab_mark );
						character[ 0 ] = p->tab_mark[ 0 ];
					}
				}
			}

			n_win_txtbox_draw_text( p, character, cch, &rect, p->drawtext_modes | DT_CENTER );

		}


		if ( is_highlighted )
		{

			if ( caret_fx == -1 ) { caret_fx = tail_x; }
			caret_tx = tail_x + size.cx;

		} else {

			if (
				( ( p->line_min_onoff )&&( text_x == p->line_max_cch_x ) )
				||
				( ( p->line_max_onoff )&&( text_x == p->line_min_cch_x ) )
				||
				( text_x == p->select_cch_x )
			)
			{
				//caret_fx = tail_x;
				caret_tx = tail_x;
			}

		}

		int inc = n_string_doublebyte_increment( text[ text_x ] );
		if (
			( n_unicode_surrogatepair_is_hi( character[ 0 ] ) )
			&&
			( n_unicode_surrogatepair_is_lo( character[ 1 ] ) )
		)
		{
			inc = 2;
		}

		text_x += inc;
		tail_x += size.cx;

	}


	if ( editbox )
	{

		// End-Of-Line Marker

		if ( ( eol_onoff )&&( (u32) text_y < p->txt.sy ) )
		{
			n_win_txtbox_draw_eol( p, tail_x,y, bg, eol_str );
		}


		// Caret

		// [!] : don't use p->hover_cch_y : value will be changed when scrolled

		s32 line_fy = n_posix_minmax( 0, p->txt.sy - 1, p->drag_cch_y - ( p->select_cch_sy - 1 ) );
		s32 line_ty = p->select_cch_y + p->select_cch_sy - 1;

		if ( p->line_min_onoff )
		{
			line_fy = p->select_cch_y + p->select_cch_sy - 1;
		} else
		if ( p->line_max_onoff )
		{
			line_fy = p->select_cch_y;
		}

		// [Mechanism]
		//
		//	#define VK_LEFT  37
		//	#define VK_UP    38
		//	#define VK_RIGHT 39
		//	#define VK_DOWN  40

//n_win_txtbox_hwndprintf_literal( p, " %d ", p->shift_dragging );

		p->is_caret_tail = false;

		s32 line    = line_ty;
		s32 caret_x = caret_tx;
		s32 caret_y = y;
		if ( p->line_min_onoff )
		{

			//

		} else
		if ( p->line_max_onoff )
		{

			line    = line_fy;
			caret_x = caret_fx;

		} else {

			if ( p->shift_dragging == VK_LEFT )
			{
				caret_x = caret_fx;
			} else
			if ( p->shift_dragging == VK_UP )
			{
				line    = line_fy;
				caret_x = caret_fx;
			} else {
				p->is_caret_tail = true;
			}

		}


		if ( ( line == text_y )&&( caret_x != -1 ) )
		{

			p->caret_pxl_x = caret_x;
			p->caret_pxl_y = caret_y;

			if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
			{
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->shift_dragging, p->select_cch_x + p->select_cch_sx );

				if ( p->shift_dragging == VK_LEFT  )
				{
					if ( ( p->select_cch_x + p->select_cch_sx ) == 0 )
					{
						p->caret_pxl_x += p->scale;
					} else {
						p->caret_pxl_x -= p->scale;
					}
				} else
				if ( p->shift_dragging == VK_RIGHT )
				{
					if ( ( p->select_cch_x + p->select_cch_sx ) == 0 )
					{
						p->caret_pxl_x -= p->scale;
					} else {
						p->caret_pxl_x += p->scale;
					}
				} else {
					if ( ( p->select_cch_x + p->select_cch_sx ) == 0 )
					{
						p->caret_pxl_x -= p->scale;
					} else {
						p->caret_pxl_x += p->scale;
					}
				}

				p->caret_pxl_x = n_posix_max_s32( p->pad_pxl_sx, p->caret_pxl_x );

			}

			n_win_txtbox_draw_caret( p );

		}

//n_win_txtbox_hwndprintf_literal( p, " %d ", line );


		// Line Number

		n_win_txtbox_draw_linenumber( p, text_y, x,y,sx,sy );

	}


	if ( bold_onoff ) { n_win_font_exit( SelectObject( p->hdc, bold_hfont ) ); }


	p->oneline_cache_t = tail_x;

	if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_LNCACHE )
	{
		n_bmp *bmp = &n_gdi_doublebuffer_32bpp_instance.bmp;

		s32 fx = p->oneline_cache_f - 2;
		s32 sx = p->oneline_cache_t - p->oneline_cache_f + 4;

		n_bmp_new_fast( &p->prv_bmp, sx,N_BMP_SY( bmp ) );
		n_bmp_fastcopy( bmp, &p->prv_bmp, fx,0,sx,N_BMP_SY( bmp ), 0,0 );
//n_bmp_save_literal( &p->prv_bmp, "ret.bmp" );
	}


	SetBkMode( p->hdc, p_bkmode );


	return;
}

// internal
void
n_win_txtbox_draw_nonclient( n_win_txtbox *p, bool is_selected, u32 color_selected )
{
//return;

	if ( p      == NULL ) { return; }
	if ( p->hdc == NULL ) { return; }


	COLORREF color_border       = p->color_base__padding;
	COLORREF color_border_mask  = p->color_base__padding;
	COLORREF color_padding      = p->color_back_noselect;
	COLORREF color_padding_mask = p->color_base__padding;
	COLORREF color_corner       = p->color_base__padding;

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{
		color_border       = 0;
		color_border_mask  = 0;
		color_padding      = 0;
		color_padding_mask = 0;
		color_corner       = 0;
	}

	if ( p->debug_onoff )
	{
		color_border       = RGB( 200,  0,255 );
		color_border_mask  = RGB( 255,255,  0 );
		color_padding      = RGB( 255,  0,  0 );
		color_padding_mask = RGB(   0,  0,255 );
		color_corner       = RGB(   0,255,  0 );
	}


	// Border

//n_win_txtbox_hwndprintf_literal( p, "%d %d", p->client_pxl_sx,p->client_pxl_sy );

	if ( false == ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR ) )
	{

		RECT r = n_win_rect_set( NULL, 0,0,p->client_pxl_sx,p->client_pxl_sy );

		// [!] : WS_EX_CLIENTEDGE causes flickering

		if (
			( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
			&&
			( false == ( p->style_option & N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE ) )
		)
		{

			if ( is_selected )
			{

				n_win_txtbox_draw_box( p, p->hdc, &r, color_selected );

			} else {

				if ( n_win_darkmode_onoff )
				{
					n_win_txtbox_draw_box( p, p->hdc, &r, p->color_border_normal );
				} else
				if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
				{
					n_win_txtbox_draw_box( p, p->hdc, &r, n_bmp_white );
				} else
				if ( p->style & N_WIN_TXTBOX_STYLE_FLATBDR )
				{
					n_win_txtbox_draw_border( p, true );
				} else
				if ( p->style & N_WIN_TXTBOX_STYLE_CMB_BDR )
				{
					n_win_txtbox_draw_border( p, false );
				} else
				if ( p->uxtheme.onoff )
				{
					p->uxtheme.DrawThemeBackground( p->uxtheme.htheme, p->hdc, EP_EDITBORDER_NOSCROLL, EPSN_NORMAL, &r, NULL );
				} else {
					DrawEdge( p->hdc, &r, EDGE_SUNKEN, BF_RECT );
				}

			}

		} else {

			if ( p->is_classic )
			{

				if ( p->style & N_WIN_TXTBOX_STYLE_FLATBDR )
				{
					n_win_txtbox_draw_border( p, true );
				} else
				if ( p->style & N_WIN_TXTBOX_STYLE_CMB_BDR )
				{
					n_win_txtbox_draw_border( p, false );
				} else {
					DrawEdge( p->hdc, &r, EDGE_SUNKEN, BF_RECT );
				}

			} else {

				if ( p->style & N_WIN_TXTBOX_STYLE_FLATBDR )
				{
					n_win_txtbox_draw_border( p, true );
				} else
				if ( p->style & N_WIN_TXTBOX_STYLE_CMB_BDR )
				{
					n_win_txtbox_draw_border( p, false );
				} else
				if ( p->uxtheme.onoff )
				{
					int state = EPSN_NORMAL;
					if ( p->hwnd == GetFocus() ) { state = EPSN_FOCUSED; }
					p->uxtheme.DrawThemeBackground( p->uxtheme.htheme, p->hdc, EP_EDITBORDER_NOSCROLL, state, &r, NULL );
				} else {
					DrawEdge( p->hdc, &r, EDGE_SUNKEN, BF_RECT );
				}


			}

		}

		if ( p->debug_onoff )
		{
			n_win_txtbox_draw_box( p, p->hdc, &r, color_border );
		}

	}

	// Mask Border

	if ( false == ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR ) )
	{

		// [Needed] : for text clipping

		s32  x = 0;
		s32  y = 0;
		s32 sx = p->client_pxl_sx;
		s32 sy = p->client_pxl_sy;
		s32 ox = sx - p->border_pxl_sx;
		s32 oy = sy - p->border_pxl_sy;
		s32 bx = p->border_pxl_sx;
		s32 by = p->border_pxl_sy;

		if ( p->debug_onoff )
		{
			RECT r;
			n_win_rect_set_simple( &r,  x,  y,      sx,      by ); n_win_txtbox_draw_box( p, p->hdc, &r, color_border_mask );
			n_win_rect_set_simple( &r,  x, oy,      sx, oy + by ); n_win_txtbox_draw_box( p, p->hdc, &r, color_border_mask );
			n_win_rect_set_simple( &r,  x,  y,      bx,      sy ); n_win_txtbox_draw_box( p, p->hdc, &r, color_border_mask );
			n_win_rect_set_simple( &r, ox,  y, ox + bx,      sy ); n_win_txtbox_draw_box( p, p->hdc, &r, color_border_mask );
		}

		ExcludeClipRect( p->hdc,  x,  y,      sx,      by );
		ExcludeClipRect( p->hdc,  x, oy,      sx, oy + by );
		ExcludeClipRect( p->hdc,  x,  y,      bx,      sy );
		ExcludeClipRect( p->hdc, ox,  y, ox + bx,      sy );

	}


	// Corner : before padding

	if (
		( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
		&&
		( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	)
	{

		// [!] : blank at bottom-right corner

		s32  tsx = p->scrollbar_pxl_sx;
		s32  tsy = p->scrollbar_pxl_sy;
		s32   tx = p->client_pxl_sx - p->scrollbar_pxl_sx - p->border_pxl_sx;
		s32   ty = p->client_pxl_sy - p->scrollbar_pxl_sy - p->border_pxl_sy;
		RECT   r = n_win_rect_set( NULL, tx, ty, tsx, tsy );

		if ( p->debug_onoff )
		{
			n_bmp_mixer( p->debug_bmp, tx, ty, tsx, tsy, color_corner, 0.5 );
		} else {
			n_win_txtbox_draw_box( p, p->hdc, &r, color_corner );
		}

		ExcludeClipRect( p->hdc, r.left, r.top, r.right, r.bottom );

	}


	// Padding

	if ( false == ( p->style & N_WIN_TXTBOX_STYLE_NO_PDNG ) )
	{

		// [Needed] : Win9x : padding will be black

		// [!] : for performance : accurate calculation is too much complicated

		s32  x = p->border_pxl_sx;
		s32  y = p->border_pxl_sy;
		s32 sx = p->client_pxl_sx - ( x * 2 );
		s32 sy = p->client_pxl_sy - ( y * 2 );

		RECT r;

		COLORREF clr = color_padding;

		n_win_rect_set( &r, x, y, sx, sy );
		n_win_txtbox_draw_box( p, p->hdc, &r, clr );

	}

	// Mask Padding

	if ( false == ( p->style & N_WIN_TXTBOX_STYLE_NO_PDNG ) )
	{

		// [Needed] : for text clipping

		s32 pad_sx = p->pad_pxl_sx;
		s32 pad_sy = p->pad_pxl_sy;
		s32      x = p->border_pxl_sx;
		s32      y = p->border_pxl_sy;
		s32     sx = p->canvas_pxl_sx + ( pad_sx * 2 );
		s32     sy = p->canvas_pxl_sy + ( pad_sy * 2 );
		s32    csx = p->client_pxl_sx;
		s32    csy = p->client_pxl_sy;

		if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
		{
			csy -= p->scrollbar_pxl_sy;
		}

		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
		{
			csx -= p->scrollbar_pxl_sx;
		}

		s32 ox = csx - pad_sx - p->smallbutton_margin;
		s32 oy = csy - pad_sy;

		// [!] : top bottom left right in order

		if ( p->debug_onoff )
		{
			RECT r;
			n_win_rect_set_simple( &r,  x,  y,     sx, pad_sy ); n_win_txtbox_draw_box( p, p->hdc, &r, color_padding_mask );
			n_win_rect_set_simple( &r,  x, oy,     sx,    csy ); n_win_txtbox_draw_box( p, p->hdc, &r, color_padding_mask );
			n_win_rect_set_simple( &r,  x,  y, pad_sx,     sy ); n_win_txtbox_draw_box( p, p->hdc, &r, color_padding_mask );
			n_win_rect_set_simple( &r, ox,  y,    csx,     sy ); n_win_txtbox_draw_box( p, p->hdc, &r, color_padding_mask );
		}

		if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		{
			ExcludeClipRect( p->hdc,  x,  y,     sx, pad_sy );
			//ExcludeClipRect( p->hdc,  x, oy,     sx,    csy ); // [!] : for "g"
			ExcludeClipRect( p->hdc,  x,  y, pad_sx,     sy );
			ExcludeClipRect( p->hdc, ox,  y,    csx,     sy );
		} else {

			ExcludeClipRect( p->hdc,  x,  y,     sx, pad_sy );
			ExcludeClipRect( p->hdc,  x, oy,     sx,    csy );
			ExcludeClipRect( p->hdc,  x,  y, pad_sx,     sy );
			ExcludeClipRect( p->hdc, ox,  y,    csx,     sy );

		}

	}


	return;
}

// internal
void
n_win_txtbox_draw_scrollbars( n_win_txtbox *p, bool mask )
{
//return;

	if ( p == NULL ) { return; }

	if ( ( mask )&&( p->hdc == NULL ) ) { return; }


	// Scrollbars

	if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
	{

		// Horizontal / X

		s32 sx = p->client_pxl_sx;
		s32 sy = p->scrollbar_pxl_sy;
		s32  x = 0;
		s32  y = p->client_pxl_sy - p->scrollbar_pxl_sy - p->offset_pxl_y;

		x  += p->border_pxl_sx;
		y  -= p->border_pxl_sy;
		sx -= p->border_pxl_sx * 2;
		//sy -= p->border_pxl_sy * 2;

		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL ) { sx -= p->scrollbar_pxl_sx; }


		if ( mask )
		{

			if ( p->debug_onoff )
			{
				RECT r = n_win_rect_set_simple( &r, x, y, x + sx, y + sy );
				n_win_txtbox_draw_box( p, p->hdc, &r, RGB( 0,255,255 ) );
			}

			ExcludeClipRect( p->hdc, x, y, x + sx, y + sy );

		} else {

			if ( p->debug_onoff )
			{
				n_bmp_mixer( p->debug_bmp, x,y,sx,sy, RGB( 255,255,0 ), 0.5 );
			} else {
				n_win_scrollbar_move( &p->hscr, x,y,sx,sy, false );
			}


			bool onoff;

			if ( p->is_font_monospace )
			{
				onoff = ( (u32) ( p->page_pxl_tabbed_sx / p->font_pxl_sx ) < p->txt.sx );
			} else {
				SIZE size = n_win_txtbox_size_text( p, n_txt_get( &p->txt, p->txt_maxwidth_y ) );
				onoff = ( p->page_pxl_tabbed_sx < size.cx );
			}

			if ( onoff )
			{

				s32 pos  = p->scroll_pxl_tabbed_x;
				s32 page = p->  page_pxl_tabbed_sx;
				s32 max  = p->  last_pxl_tabbed_sx;

				n_win_scrollbar_parameter( &p->hscr, p->font_pxl_sx, page, max, pos, false );

			}

			n_win_scrollbar_enable( &p->hscr, onoff, false );

			n_win_scrollbar_draw_always( &p->hscr, true );

		}

	}

	if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	{

		// Vertical / Y

		s32 sx = p->scrollbar_pxl_sx;
		s32 sy = p->client_pxl_sy;
		s32  x = p->client_pxl_sx - p->scrollbar_pxl_sx;
		s32  y = -p->offset_pxl_y;

		x  -= p->border_pxl_sx;
		y  += p->border_pxl_sy;
		//sx -= p->border_pxl_sx * 2;
		sy -= p->border_pxl_sy * 2;

		if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL ) { sy -= p->scrollbar_pxl_sy; }


		if ( mask )
		{

			if ( p->debug_onoff )
			{
				RECT r = n_win_rect_set_simple( &r, x, y, x + sx, y + sy );
				n_win_txtbox_draw_box( p, p->hdc, &r, RGB( 0,255,255 ) );
			}

			ExcludeClipRect( p->hdc, x, y, x + sx, y + sy );

		} else {

			if ( p->debug_onoff )
			{
				n_bmp_mixer( p->debug_bmp, x,y,sx,sy, RGB( 255,255,0 ), 0.5 );
			} else {
				n_win_scrollbar_move( &p->vscr, x,y,sx,sy, false );
			}

			bool onoff = ( (u32) p->page_cch_tabbed_sy < p->txt.sy );

			if ( onoff )
			{

				s32 step = p->cell_pxl_sy;
				s32 pos  = p->cell_pxl_sy * p->scroll_cch_tabbed_y;
				s32 page = p->cell_pxl_sy * p->  page_cch_tabbed_sy;
				s32 max  = p->cell_pxl_sy * p->  last_cch_tabbed_sy;

//n_win_txtbox_hwndprintf_literal( p, " %g %g ", p->vscr.pixel_thumb_original, p->vscr.pixel_thumb );

				n_win_scrollbar_parameter( &p->vscr, step, page, max, pos, false );

			}

			n_win_scrollbar_enable( &p->vscr, onoff, false );

			n_win_scrollbar_draw_always( &p->vscr, true );


//n_win_hwndprintf_literal( n_win_hwnd_toplevel( p->hwnd ), " %g ", p->vscr.rect_main.y );

		}

	}


	return;
}

void
n_win_txtbox_draw_fade( n_win_txtbox *p, n_bmp *bmp, double ratio )
{

	n_bmp bmp_f; n_bmp_carboncopy(                                    bmp, &bmp_f );
	n_bmp bmp_t; n_bmp_carboncopy( &n_gdi_doublebuffer_32bpp_instance.bmp, &bmp_t );

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{
		//
	} else {
		n_bmp_alpha_visible( &bmp_f );
		n_bmp_alpha_visible( &bmp_t );
	}
/*
if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
{
	n_bmp_save_literal( &bmp_f, "f.bmp" );
	n_bmp_save_literal( &bmp_t, "t.bmp" );
}
*/
	bmp_f.transparent_onoff = false;
	bmp_t.transparent_onoff = false;

	n_bmp_flush_blendcopy( &bmp_f, &bmp_t, ratio );

	bmp_f.transparent_onoff =  true;
	bmp_t.transparent_onoff =  true;

	n_bmp_flush_fastcopy( &bmp_t, &n_gdi_doublebuffer_32bpp_instance.bmp );

//n_bmp_save_literal( &n_gdi_doublebuffer_32bpp_instance.bmp, "db.bmp" );

	n_bmp_free_fast( &bmp_f );
	n_bmp_free_fast( &bmp_t );


	return;
}

#define n_win_txtbox_draw( p ) n_win_txtbox_draw_partial( p, NULL, true, -1, -1 )

#define n_win_txtbox_draw_selection( p ) n_win_txtbox_draw_partial( p, NULL, false, (p)->select_cch_y, (p)->select_cch_sy );

// internal
void
n_win_txtbox_draw_partial( n_win_txtbox *p, RECT *r, bool nonclient, s32 line_y, s32 line_sy )
{
//n_win_txtbox_debug_count( p );

	if ( p == NULL ) { return; }

	if ( n_txt_error( &p->txt ) ) { return; }


	// Debug Center

	//u32 benchmark = n_posix_tickcount();

	if ( p->debug_onoff )
	{
		//p->style &= ~( N_WIN_TXTBOX_STYLE_HSCROLL | N_WIN_TXTBOX_STYLE_VSCROLL ); 
		//p->style |= N_WIN_TXTBOX_STYLE_HSCROLL;
		//p->style |= N_WIN_TXTBOX_STYLE_VSCROLL;
		//p->style |= N_WIN_TXTBOX_STYLE_HSCROLL | N_WIN_TXTBOX_STYLE_VSCROLL;
	}


	// Canvas Metrics : this cannot be put into n_win_txtbox_draw_nonclient()

	if ( nonclient )
	{
		n_win_txtbox_metrics_canvas( p );
		n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_cch_tabbed_y );
	}


	// Draw

	if ( p->hdc != NULL )
	{

		//

	} else
	if ( p->is_9x )
	{

		n_gdi_doublebuffer_simple_zero();
		p->hdc = n_gdi_doublebuffer_simple_init( p->hwnd, p->client_pxl_sx, p->client_pxl_sy );

		n_gdi_doublebuffer_instance.bmp.transparent_onoff = false;

	} else {

		s32 tmp_sy = p->client_pxl_sy;

		if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
		{
			tmp_sy *= -1;
			n_gdi_doublebuffer_32bpp_instance.upsidedown = true;
		}

		n_gdi_doublebuffer_simple_zero();
		p->hdc = n_gdi_doublebuffer_32bpp_simple_init( p->hwnd, p->client_pxl_sx, tmp_sy );

		n_gdi_doublebuffer_32bpp_instance.bmp.transparent_onoff = false;

	}


	if ( p->debug_onoff )
	{
		p->debug_bmp = &n_gdi_doublebuffer_32bpp_instance.bmp;
	}


	// [Needed] : Vista/7 : corner needs this

	//if ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR )
	{
		RECT rect = n_win_rect_set( NULL, 0,0, p->client_pxl_sx,p->client_pxl_sy );
		n_win_txtbox_draw_box( p, p->hdc, &rect, p->color_back_noselect );
	}


	// [x] : a caret needs this always : when a line with a caret is out of client area

	double ratio = 1.0;

	bool fade_is_on = n_win_fade_is_on();
	bool is_visible = ( p->style & N_WIN_TXTBOX_STYLE_VISIBLE ); 

	if ( fade_is_on )
	{
		n_bmp_fade_engine( &p->fade, fade_is_on );
		ratio = (double) p->fade.percent * 0.01;
	}

	if (
//(0)&&
		( p->is_9x == false )
		&&
		( ( fade_is_on )||( is_visible ) )
		&&
		( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		&&
		( false == ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR ) )
	)
	{

		// [Needed] : for ExcludeClipRect()

		n_win_txtbox_draw_nonclient( p, ( p->hwnd == GetFocus() ), p->color_back_selected );


		n_bmp bmp_f, bmp_t;


		n_gdi_doublebuffer db; n_gdi_doublebuffer_zero( &db );


		// [x] : WinVista/7 : DWM is ON : fail to get as bitmap

		if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
		{

			n_bmp_zero( &bmp_f );
			n_bmp_zero( &bmp_t );

			n_bmp_new_fast( &bmp_f, p->client_pxl_sx,p->client_pxl_sy );
			n_bmp_new_fast( &bmp_t, p->client_pxl_sx,p->client_pxl_sy );

			n_bmp_flush( &bmp_f, 0 );
			n_bmp_flush( &bmp_t, 0 );

			n_gdi gdi; n_gdi_zero( &gdi );

			u32 color_bg = n_bmp_alpha_visible_pixel( n_bmp_pal2rgb( p->fade.color_bg ) );

			if ( p->fade.color_bg == n_bmp_black )
			{
				gdi.scale = 1 * p->scale;
				n_gdi_frame_lineframe( &gdi, &bmp_f, 0,0,p->client_pxl_sx,p->client_pxl_sy, n_bmp_white );
			} else {
				gdi.scale = 2 * p->scale;
				n_gdi_frame_lineframe( &gdi, &bmp_f, 0,0,p->client_pxl_sx,p->client_pxl_sy, color_bg    );
			}

			u32 color_fg = n_bmp_alpha_visible_pixel( n_bmp_pal2rgb( p->fade.color_fg ) );

			if ( p->fade.color_fg == n_bmp_black )
			{
				gdi.scale = 1 * p->scale;
				n_gdi_frame_lineframe( &gdi, &bmp_t, 0,0,p->client_pxl_sx,p->client_pxl_sy, n_bmp_white );
			} else {
				gdi.scale = 2 * p->scale;
				n_gdi_frame_lineframe( &gdi, &bmp_t, 0,0,p->client_pxl_sx,p->client_pxl_sy, color_fg    );
			}

		} else {

			HDC hdc_main = p->hdc;


			p->hdc = n_gdi_doublebuffer_32bpp_init( &db, p->hwnd, hdc_main, p->client_pxl_sx, p->client_pxl_sy );

			// [Needed] : corner has alpha value
			n_bmp_flush( &db.bmp, n_gdi_systemcolor( COLOR_BTNFACE ) );

			if ( p->fade.color_bg == n_bmp_black )
			{
				n_win_txtbox_draw_nonclient( p, false, p->color_back_selected );
			} else {
				n_win_txtbox_draw_nonclient( p,  true, p->fade.color_bg       );
			}

			n_bmp_carboncopy( &db.bmp, &bmp_f );
			n_bmp_alpha_visible( &bmp_f );

			n_gdi_doublebuffer_32bpp_cleanup( &db );


			p->hdc = n_gdi_doublebuffer_32bpp_init( &db, p->hwnd, hdc_main, p->client_pxl_sx, p->client_pxl_sy );

			// [Needed] : corner has alpha value
			n_bmp_flush( &db.bmp, n_gdi_systemcolor( COLOR_BTNFACE ) );

			if ( p->fade.color_fg == n_bmp_black )
			{
				n_win_txtbox_draw_nonclient( p, false, p->color_back_selected );
			} else {
				n_win_txtbox_draw_nonclient( p,  true, p->fade.color_fg       );
			}

			n_bmp_carboncopy( &db.bmp, &bmp_t );
			n_bmp_alpha_visible( &bmp_t );

			n_gdi_doublebuffer_32bpp_cleanup( &db );


			p->hdc = hdc_main;

		}

//n_bmp_save_literal( &bmp_f, "f.bmp" );
//n_bmp_save_literal( &bmp_t, "t.bmp" );


		n_bmp_flush_blendcopy( &bmp_f, &bmp_t, ratio );


		n_bmp_flush_fastcopy( &bmp_t, &n_gdi_doublebuffer_32bpp_instance.bmp );


		n_bmp_free_fast( &bmp_f );
		n_bmp_free_fast( &bmp_t );


//n_bmp_alpha_reverse( &n_gdi_doublebuffer_32bpp_instance.bmp );

//n_gdi_bitmap_draw_main( p->hwnd, p->hdc, &bmp_t, 0, 0, p->client_pxl_sx, p->client_pxl_sy, 0, 0 );

//n_win_txtbox_hwndprintf_literal( p, " %d %f ", p->fade.percent, ratio );

	} else {

		n_win_txtbox_draw_nonclient( p, ( p->hwnd == GetFocus() ), p->color_back_selected );

		if ( p->debug_onoff )
		{
			n_win_txtbox_draw_scrollbars( p, false );
		}

		n_win_txtbox_draw_scrollbars( p, true );

	}


	if ( r == NULL )
	{
		if ( line_y  == -1 ) { line_y  = p->scroll_cch_tabbed_y;                         }
		if ( line_sy == -1 ) { line_sy = p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy; }
	} else {
		s32 y, sy; n_win_rect_expand_size( r, NULL, &y, NULL, &sy );
		line_y  = ( ( y - p->pad_pxl_sy ) / p->cell_pxl_sy ) + p->scroll_cch_tabbed_y;
		line_sy = sy / p->cell_pxl_sy;
	}

	if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
	{
		SIZE sz = n_win_txtbox_size_text( p, n_posix_literal( "y" ) );
		line_sy = n_posix_max_s32( sz.cy, line_sy );
	}

	s32 psx = ( p->pad_pxl_sx );
	s32 psy = ( p->pad_pxl_sy );
	s32 ox  = (           p->scroll_pxl_tabbed_x );
	s32 oy  = ( line_y  - p->scroll_cch_tabbed_y ) * p->cell_pxl_sy;
	s32 osy = ( line_sy                          ) * p->cell_pxl_sy;

	oy -= p->offset_pxl_y;

	if ( p->style & N_WIN_TXTBOX_STYLE_NO_PDNG )
	{
		ox += p->border_pxl_sx;
		oy += p->border_pxl_sy;
 	}

	{ // Text

		s32 x  = psx - ox;
		s32 y  = psy + oy;
		s32 sx = p->canvas_pxl_sx;
		s32 sy = p->canvas_pxl_sy;

		// [Needed] : high-DPI

		if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		{
			y = abs( p->client_pxl_sy - p->font_pxl_sy ) / 2;
		}

		if (
			( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
			&&
			( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
		)
		{
			 x += p->number_pxl_sx + p->number_pad_pxl_sx;
			sx -= p->number_pxl_sx + p->number_pad_pxl_sx;
		}

		s32 text_fy = line_y;
		s32 text_ty = line_y + line_sy;
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", text_fy, text_ty );

		// [x] : this section is called many times than needed

		while( 1 )
		{//break;
//n_win_txtbox_debug_count( p );

			n_win_txtbox_draw_singleline( p, text_fy, x, y, sx, p->cell_pxl_sy );

			text_fy++;
			if ( text_fy >= text_ty )
			{
//n_win_txtbox_hwndprintf_literal( p, " 1 " );
				break;
			}

			y += p->cell_pxl_sy;
			if ( y >= sy )
			{
//n_win_txtbox_hwndprintf_literal( p, " 2 " );
				break;
			}

		}

	} // Text

/*
	{ // Mask Debug

		RECT r = n_win_rect_set( NULL, 0,0, p->client_pxl_sx,p->client_pxl_sy );
		n_win_clear( p->hwnd, p->hdc, &r, COLOR_BTNFACE );

	} // Mask Debug
*/

	{ // Sync
//n_gdi_doublebuffer_32bpp_simple_exit();

		s32 redraw_x  = 0;
		s32 redraw_y  = 0;
		s32 redraw_sx = 0;
		s32 redraw_sy = 0;

		if ( nonclient )
		{
			n_win_rect_expand_size( r, &redraw_x, &redraw_y, &redraw_sx, &redraw_sy );
		} else {
			redraw_x  = psx;
			redraw_y  = psy + oy;
			redraw_sx = p->canvas_pxl_sx + 1;
			redraw_sy = osy;
		}

		if ( p->is_9x )
		{

			n_gdi_doublebuffer_simple_exit_partial( redraw_x, redraw_y, redraw_sx, redraw_sy );

		} else
		if ( ( ( fade_is_on )||( is_visible ) ) == false )
		{

			n_gdi_doublebuffer_32bpp_simple_exit_partial( redraw_x, redraw_y, redraw_sx, redraw_sy );

		} else {

			if (
				( p->style        & N_WIN_TXTBOX_STYLE_ONELINE          )
				&&
				( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_FADEOUT )
				&&
				( n_string_is_empty( n_txt_get( &p->txt, 0 ) ) )
			)
			{

				if ( p->fade.stop == false )
				{
//n_win_txtbox_debug_count( p );
					n_win_txtbox_draw_fade( p, &p->fade_bmp, ratio );
//n_bmp_save_literal( &p->fade_bmp, "fade2.bmp" );
				} else {
					n_bmp_free( &p->fade_bmp );
				}

			} else
			if ( false == ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
			{
//n_win_txtbox_debug_count( p );

				if ( p->fade.stop == false )
				{
					n_win_txtbox_draw_fade( p, &p->ime_bmp, ratio );
				}

			}


			if ( nonclient )
			{
				n_bmp_free_fast( &p->ime_bmp );
				n_bmp_carboncopy( &n_gdi_doublebuffer_32bpp_instance.bmp, &p->ime_bmp );
			} else {
				n_bmp_fastcopy
				(
					&n_gdi_doublebuffer_32bpp_instance.bmp,
					&p->ime_bmp,
					redraw_x, redraw_y, redraw_sx, redraw_sy,
					redraw_x, redraw_y
				);
			}


			if (
				( p->style        & N_WIN_TXTBOX_STYLE_ONELINE          )
				&&
				( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_FADEOUT )
				&&
				( false == n_string_is_empty( n_txt_get( &p->txt, 0 ) ) )
			)
			{
				n_bmp_free_fast( &p->fade_bmp );
				n_bmp_carboncopy( &n_gdi_doublebuffer_32bpp_instance.bmp, &p->fade_bmp );
			}


			if ( p->style & N_WIN_TXTBOX_STYLE_VISIBLE )
			{
				n_gdi_doublebuffer_32bpp_simple_visible();
			}


			n_gdi_doublebuffer_32bpp_simple_exit_partial( redraw_x, redraw_y, redraw_sx, redraw_sy );

		}

		p->hdc = NULL;

	} // Sync


	// [Needed] : after text is drawn

	if ( ( p->debug_onoff == false )&&( nonclient ) )
	{
		n_win_txtbox_draw_scrollbars( p, false );
	}


	if ( p->style & N_WIN_TXTBOX_STYLE_FLATBDR )
	{
		HWND hwnd = GetParent( p->hwnd );
		HDC  hdc  = GetDC    (    hwnd );

		n_win_txtbox_draw_border( p, true );

		ReleaseDC( hwnd, hdc );
	}

/*
static int count = 0; count++;
n_win_txtbox_hwndprintf_literal
(
	p,
	"Count %d"
	" : "
	"Selection : %d %d %d %d"
	" : "
	"Hover : %d %d"
	" : "
	"Drag %d : %d %d"
	"",
	count,
	p->select_cch_x, p->select_cch_y, p->select_cch_sx, p->select_cch_sy,
	p->hover_cch_x, p->hover_cch_y,
	p->shift_dragging, p->drag_cch_x, p->drag_cch_y
);
*/

//n_win_txtbox_hwndprintf_literal( p, "%d", p->txt.sx );


//n_win_txtbox_hwndprintf_literal( p, "%d", n_posix_tickcount() - benchmark );


	return;
}


