// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define N_ORANGECAT_COLOR_BLACK  n_bmp_rgb(  10, 10, 10 )




typedef struct {

	u32 bg;

	u32 path_text;
	u32 path_bg;
	u32 path_press;
	u32 path_hover;
	u32 path_drop;
	u32 path_frame1;
	u32 path_frame2;
	u32 path_luna;

	u32 item_text;
	u32 item_hover;
	u32 item_focus;
	u32 item_key_i;
	u32 item_key_o;
	u32 item_zebra;
	u32 item_shadow;
	u32 item_select;
	u32 item_gauge;
	u32 item_copy;

	u32 info_bg_1;
	u32 info_bg_2;

} n_oc_color;


static n_oc_color oc_color;




// internal
void
n_oc_color_debug( u32 color )
{

	n_posix_debug_literal
	(
		"%d %d %d %d",
		n_bmp_a( color ),
		n_bmp_r( color ),
		n_bmp_g( color ),
		n_bmp_b( color )
	);


	return;
}

bool
n_oc_color_is_same( u32 color1, u32 color2 )
{

	// [!] : alpha will be skipped

	int r1 = n_bmp_r( color1 );
	int g1 = n_bmp_g( color1 );
	int b1 = n_bmp_b( color1 );

	int r2 = n_bmp_r( color2 );
	int g2 = n_bmp_g( color2 );
	int b2 = n_bmp_b( color2 );


	return ( ( r1 == r2 )&&( g1 == g2 )&&( b1 == b2 ) );
}




u32
n_oc_color_system( int color_name )
{

	u32 color = n_gdi_systemcolor( color_name );


	if ( color_name == COLOR_ACTIVECAPTION )
	{
		color = n_win_dwm_windowcolor();
	}


	if ( n_oc_color_is_same( color, n_bmp_black ) )
	{
		color = N_ORANGECAT_COLOR_BLACK;
	}


	return n_bmp_alpha_visible_pixel( color );
}

bool
n_oc_color_is_highcontrast_white( void )
{

	bool ret = false;

	if ( n_bmp_white == n_oc_color_system( COLOR_WINDOW ) ) { ret = true; }

	return ret;
}

bool
n_oc_color_is_highcontrast_black( void )
{

	bool ret = false;

	if ( N_ORANGECAT_COLOR_BLACK == n_oc_color_system( COLOR_WINDOW ) ) { ret = true; }

	return ret;
}




u32
n_oc_color_background( u32 bg, u32 fg )
{

	bg = n_bmp_alpha_invisible_pixel( bg );
	fg = n_bmp_alpha_invisible_pixel( fg );

	return n_bmp_blend_pixel( bg, fg, 0.5 );
}




u32
n_oc_color_dwm_textshadow( void )
{

	u32 bg = n_oc_color_system( COLOR_ACTIVECAPTION );
	u32 fg = N_ORANGECAT_COLOR_BLACK;


	double coeff = 0.0;

	{

		u32 color = n_bmp_argb2ahsl( bg );

		int l = n_bmp_lightness( color );

		coeff = (double) l / 255;

//n_posix_debug_literal( "%d : %f", l, coeff );
	}


	return n_bmp_blend_pixel( bg, fg, coeff * 1.75 );
}




u32
n_oc_color_path_hover( void )
{
	return n_oc_color_system( COLOR_HIGHLIGHT );
}

u32
n_oc_color_path_drop( double ratio )
{
	return n_bmp_blend_pixel( n_oc_color_system( COLOR_HIGHLIGHT ), n_bmp_rgb( 255,128,0 ), ratio );
}

u32
n_oc_color_path_luna( void )
{

	u32 bg = n_oc_color_system( COLOR_3DDKSHADOW );
	u32 fg = n_oc_color_system( COLOR_HIGHLIGHT  );

	return n_bmp_blend_pixel( bg, fg, 0.5 );
}




u32
n_oc_color_item_hover( void )
{

	u32 color;

	if ( oc.dwm_onoff )
	{

		// [!] : I don't know the better way

		u32 fg = n_oc_color_system( COLOR_CAPTIONTEXT   );
		u32 bg = n_oc_color_system( COLOR_ACTIVECAPTION );

		color = n_bmp_blend_pixel( bg, fg, 0.5 );

	} else {

		color = n_oc_color_system( COLOR_HIGHLIGHT );

	}


	return color;
}




u32
n_oc_color_aero_path_bg( void )
{

	u32 fg = n_oc_color_system( COLOR_ACTIVECAPTION );
	u32 bg = N_ORANGECAT_COLOR_BLACK;
//n_oc_color_debug( fg );
//n_oc_color_debug( bg );
	return n_bmp_blend_pixel( bg, fg, 0.50 );
}

u32
n_oc_color_aero_path_press( void )
{

	u32 fg = n_oc_color_system( COLOR_ACTIVECAPTION );
	u32 bg = N_ORANGECAT_COLOR_BLACK;

	return n_bmp_blend_pixel( bg, fg, 0.33 );
}

u32
n_oc_color_aero_hover( void )
{

	u32 color = n_bmp_argb2ahsl( n_oc_color_system( COLOR_ACTIVECAPTION ) );

	int a = n_bmp_a( color );
	int h = n_bmp_h( color );
	int s = n_bmp_s( color );
	int l = n_bmp_l( color );
//n_posix_debug_literal( " %d %d %d ", h, s, l );

	l = 100;//n_posix_max( 128, l );

	if ( false == n_sysinfo_version_8_or_later() )
	{
		s = 200;
		l = 150;
	}

	color = n_bmp_ahsl2argb( n_bmp_ahsl( a,h,s,l ) );


	return color;
}

u32
n_oc_color_aero_alpha_pixel( u32 color )
{

	int a = n_bmp_a( color );
	int r = n_bmp_r( color );
	int g = n_bmp_g( color );
	int b = n_bmp_b( color );

	a = n_bmp_blend_channel( a, N_BMP_ALPHA_CHANNEL_INVISIBLE, 0.05 );

	// [!] : Debug
	//r = 255;


	return n_bmp_argb( a, r, g, b );
}

void
n_oc_color_aero_alpha( n_bmp *bmp )
{

	// [!] : no error check here

	//if ( n_sysinfo_version_8_or_later() ) { return; }

	s32  o = 1;
	s32 oo = 2;

	s32  x = 0 + o;
	s32  y = 0 + o;
	s32 sx = N_BMP_SX( bmp ) - oo;
	s32 sy = N_BMP_SY( bmp ) - oo;
	while( 1 )
	{

		u32 color; n_bmp_ptr_get_fast( bmp, x,y, &color );

		if ( N_BMP_ALPHA_CHANNEL_INVISIBLE != n_bmp_a( color ) )
		{
			n_bmp_ptr_set_fast( bmp, x,y, n_oc_color_aero_alpha_pixel( color ) );
		}

		x++;
		if ( x >= sx )
		{

			x = 0 + o;

			y++;
			if ( y >= sy ) { break; }
		}
	}


	return;
}




u32
n_oc_color_aqua_path_text( void )
{

	u32 color = n_bmp_argb2ahsl( n_oc_color_path_hover() );

	int a = n_bmp_a( color );
	int h = n_bmp_h( color );
	int s = n_bmp_s( color );
	int l = n_bmp_l( color );
//n_posix_debug_literal( " %d %d %d ", h, s, l );

	s = 255;
	l =   0;

	color = n_bmp_ahsl2argb( n_bmp_ahsl( a,h,s,l ) );


	return color;
}

u32
n_oc_color_aqua_path_bg( void )
{

	u32 color = n_bmp_argb2ahsl( n_oc_color_path_hover() );

	int a = n_bmp_a( color );
	int h = n_bmp_h( color );
	int s = n_bmp_s( color );
	int l = n_bmp_l( color );
//n_posix_debug_literal( " %d %d %d ", h, s, l );

	s = n_posix_max( 128     , s );
	l = n_posix_max( 128 + 12, l );

	color = n_bmp_ahsl2argb( n_bmp_ahsl( a,h,s,l ) );


	return color;
}

u32
n_oc_color_aqua_path_hover( void )
{

	u32 color = n_bmp_argb2ahsl( n_oc_color_path_hover() );

	int a = n_bmp_a( color );
	int h = n_bmp_h( color );
	int s = n_bmp_s( color );
	int l = n_bmp_l( color );
//n_posix_debug_literal( " %d %d %d ", h, s, l );

	h = h - 12;
	l = 255;

	color = n_bmp_ahsl2argb( n_bmp_ahsl( a,h,s,l ) );


	return color;
}

u32
n_oc_color_aqua_path_keycolor( u32 fg )
{

	u32 color = n_bmp_argb
	(
		                        n_bmp_a( fg ),
		n_bmp_simplify_channel( n_bmp_r( fg ), 64 ),
		n_bmp_simplify_channel( n_bmp_g( fg ), 64 ),
		n_bmp_simplify_channel( n_bmp_b( fg ), 64 )
	);

	return color;
}




void
n_oc_color_init( void )
{

	// [!] : Win9x : default color scheme
	//
	//	RGB( 255,255,255 ) for COLOR_SCROLLBAR
	//	RGB(   0,  0,  0 ) for COLOR_3DDKSHADOW


	// [!] : .oc_color.path_frame1, frame2
	//
	//	only used in CLASSIC and 8


	if ( n_win_darkmode_onoff )
	{

		oc_color.bg          = n_bmp_alpha_invisible_pixel( N_ORANGECAT_COLOR_BLACK );

		oc_color.path_text   = n_bmp_white;
		oc_color.path_bg     = oc_color.bg;
		oc_color.path_hover  = n_bmp_blend_pixel( oc_color.path_bg, oc_color.path_text, 0.90 );
		oc_color.path_drop   = n_oc_color_path_drop( 1.0 );
		oc_color.path_press  = n_bmp_blend_pixel( oc_color.path_bg, oc_color.path_text, 0.25 );
		oc_color.path_frame1 = n_bmp_blend_pixel( oc_color.path_bg, oc_color.path_text, 0.75 );
		oc_color.path_frame2 = n_bmp_blend_pixel( oc_color.path_bg, oc_color.path_text, 0.75 );
		oc_color.path_luna   = N_ORANGECAT_COLOR_BLACK;

		oc_color.item_text   = n_bmp_white;
		oc_color.item_hover  = n_bmp_blend_pixel( oc_color.bg, oc_color.item_text, 0.25 );
		oc_color.item_key_i  = n_bmp_blend_pixel( oc_color.bg, oc_color.item_text, 0.25 );
		oc_color.item_key_o  = n_bmp_blend_pixel( oc_color.bg, oc_color.item_text, 0.40 );
		oc_color.item_zebra  = n_bmp_blend_pixel( oc_color.bg, oc_color.item_text, 0.05 );
		oc_color.item_shadow = n_bmp_blend_pixel( oc_color.bg, oc_color.item_text, 0.75 );
		oc_color.item_gauge  = n_oc_color_system( COLOR_HIGHLIGHT );
		oc_color.item_copy   = n_oc_color_path_drop( 0.75 );

		oc_color.info_bg_1    = n_bmp_rgb( 222,222,222 );
		oc_color.info_bg_2    = n_bmp_rgb( 111,111,111 );

		oc_color.item_select  = n_bmp_blend_pixel( oc_color.bg, oc_color.item_text, 0.90 );

	} else
	if ( oc.dwm_onoff )
	{

		oc_color.bg          = n_bmp_black_invisible;

		oc_color.path_text   = n_oc_color_system( COLOR_BTNTEXT );
		oc_color.path_bg     = n_oc_color_system( COLOR_BTNFACE );
		oc_color.path_hover  = n_oc_color_path_hover();
		oc_color.path_drop   = n_oc_color_path_drop( 1.0 );
		oc_color.path_press  = n_bmp_blend_pixel( oc_color.path_bg, oc_color.path_text, 0.50 );
		oc_color.path_frame1 = n_oc_color_system( COLOR_3DSHADOW  );
		oc_color.path_frame2 = n_oc_color_system( COLOR_3DHILIGHT );
		oc_color.path_luna   = n_oc_color_path_luna();

		oc_color.item_text   = n_bmp_white;
		oc_color.item_hover  = n_bmp_blend_pixel( oc_color.bg, n_oc_color_item_hover(), 0.25 );
		oc_color.item_key_i  = n_bmp_blend_pixel( oc_color.bg,   oc_color.item_text   , 0.25 );
		oc_color.item_key_o  = n_bmp_blend_pixel( oc_color.bg, n_oc_color_item_hover(), 0.50 );
		oc_color.item_zebra  = n_bmp_blend_pixel( oc_color.bg,             n_bmp_white, 0.25 );
		oc_color.item_shadow = n_oc_color_dwm_textshadow();
		oc_color.item_gauge  = n_bmp_white;
		oc_color.item_copy   = n_oc_color_path_drop( 0.75 );

		oc_color.info_bg_1    = oc_color.path_hover;
		oc_color.info_bg_2    = n_oc_color_path_drop( 0.75 );

	} else {

		oc_color.bg          = n_bmp_alpha_invisible_pixel( n_oc_color_system( COLOR_WINDOW ) );

		oc_color.path_text   = n_oc_color_system( COLOR_BTNTEXT );
		oc_color.path_bg     = n_oc_color_system( COLOR_BTNFACE );
		oc_color.path_hover  = n_oc_color_path_hover();
		oc_color.path_drop   = n_oc_color_path_drop( 1.0 );
		oc_color.path_press  = n_bmp_blend_pixel( oc_color.path_bg, oc_color.path_text, 0.50 );
		oc_color.path_frame1 = n_oc_color_system( COLOR_3DSHADOW  );
		oc_color.path_frame2 = n_oc_color_system( COLOR_3DHILIGHT );
		oc_color.path_luna   = n_oc_color_path_luna();

		oc_color.item_text   = n_oc_color_system( COLOR_WINDOWTEXT );
		oc_color.item_hover  = n_bmp_blend_pixel( oc_color.bg, n_oc_color_item_hover(), 0.25 );
		oc_color.item_key_i  = n_bmp_blend_pixel( oc_color.bg, n_oc_color_item_hover(), 1.00 );
		oc_color.item_key_o  = n_bmp_blend_pixel( oc_color.bg, n_oc_color_item_hover(), 0.50 );
		oc_color.item_zebra  = n_bmp_blend_pixel( oc_color.bg,      oc_color.item_text, 0.05 );
		oc_color.item_shadow = n_bmp_blend_pixel( oc_color.bg,      oc_color.item_text, 0.75 );
		oc_color.item_gauge  = n_oc_color_system( COLOR_HIGHLIGHT );
		oc_color.item_copy   = n_oc_color_path_drop( 0.75 );

		oc_color.info_bg_1    = oc_color.path_hover;
		oc_color.info_bg_2    = n_oc_color_path_drop( 0.75 );


		if ( n_win_color_is_highcontrast() )
		{

			if ( n_oc_color_is_highcontrast_white() )
			{

				u32 hover = n_bmp_blend_pixel( n_bmp_white, oc_color.path_hover, 0.5 );

				oc_color.item_hover  = n_bmp_blend_pixel( oc_color.bg,              hover, 0.25 );
				oc_color.item_key_i  = n_bmp_blend_pixel( oc_color.bg, oc_color.item_text, 0.50 );
				oc_color.item_key_o  = n_bmp_blend_pixel( oc_color.bg,              hover, 0.50 );
				oc_color.item_zebra  = n_bmp_blend_pixel( oc_color.bg, oc_color.item_text, 0.05 );

			} else
			if ( n_oc_color_is_highcontrast_black() )
			{

				oc_color.path_bg      = n_oc_color_system( COLOR_BTNTEXT );
				oc_color.path_text    = n_oc_color_system( COLOR_BTNFACE );
				oc_color.path_press   = n_bmp_blend_pixel( oc_color.path_bg, oc_color.path_text, 0.50 );

			}

		}

	}


	// [!] : Style

	if ( ( oc.style == N_ORANGECAT_STYLE_LUNA )||( oc.style == N_ORANGECAT_STYLE_AERO ) )
	{

		if ( oc.style == N_ORANGECAT_STYLE_LUNA )
		{

			// [!] : Win8 or later : always rgb( 240,240,240 )

			if ( 0 == n_bmp_saturation( n_bmp_argb2ahsl( oc_color.path_bg ) ) )
			{
				oc_color.path_bg     = n_bmp_rgb( 236,233,216 );
			}

			if ( n_win_darkmode_onoff )
			{
				oc_color.path_text   = n_oc_color_system( COLOR_BTNTEXT );
			}

		} else {

			if ( n_win_darkmode_onoff )
			{
				oc_color.path_bg = n_bmp_blend_pixel( oc_color.bg, oc_color.item_text, 0.50 );
			} else {
				oc_color.path_bg = n_oc_color_aero_path_bg();
			}

		}


		if ( n_win_darkmode_onoff )
		{
			//
		} else {
			oc_color.path_hover   = n_oc_color_aero_hover();
			oc_color.path_press   = n_oc_color_aero_path_press();
		}
//n_oc_color_debug( oc_color.bg         );
//n_oc_color_debug( oc_color.path_bg    );
//n_oc_color_debug( oc_color.path_hover );


		// [!] : "oc_color.path_hover" will be overwritten

		u32 hover = oc_color.path_hover;
		u32 keyop = oc_color.item_text;

		if ( n_win_darkmode_onoff )
		{
			//
		} else {
			oc_color.item_hover   = n_bmp_blend_pixel( oc_color.bg, hover, 0.25 );
			oc_color.item_key_i   = n_bmp_blend_pixel( oc_color.bg, hover, 1.00 );
			oc_color.item_key_o   = n_bmp_blend_pixel( oc_color.bg, hover, 0.50 );
		}


		if ( n_win_color_is_highcontrast() )
		{
			if ( n_oc_color_is_highcontrast_white() )
			{
				oc_color.item_key_i = n_bmp_blend_pixel( oc_color.bg, keyop, 0.75 );
			} else
			if ( n_oc_color_is_highcontrast_black() )
			{
				oc_color.path_hover = n_bmp_white;
			}
		}

		if ( oc.style == N_ORANGECAT_STYLE_LUNA )
		{
			u32           swap  = oc_color.path_hover;
			oc_color.path_hover = oc_color.path_drop;
			oc_color.path_drop  = swap;

			if ( n_win_darkmode_onoff )
			{
				oc_color.path_drop  = n_bmp_rgb( 0,200,255 );
			} else {
				oc_color.path_drop  = n_bmp_blend_pixel( oc_color.path_drop, oc_color.path_press, 0.5 );
			}
		}

		if ( n_win_darkmode_onoff )
		{
			//
		} else {
			if ( n_win_color_is_highcontrast() )
			{
				if ( n_oc_color_is_highcontrast_white() )
				{
					//
				} else
				if ( n_oc_color_is_highcontrast_black() )
				{
					//
				}
			}

			oc_color.info_bg_1    = oc_color.item_key_o;
		}

	} else
	if ( oc.style == N_ORANGECAT_STYLE_8 )
	{

		if ( n_win_darkmode_onoff )
		{

			oc_color.path_hover   = n_bmp_rgb( 111,111,111 );
			oc_color.path_press   = n_bmp_rgb(  50, 50, 50 );

			oc_color.path_frame2  = N_ORANGECAT_COLOR_BLACK;

		} else {

			u32 path_hover = n_oc_color_path_hover();

			oc_color.path_hover   = n_bmp_blend_pixel( path_hover, oc_color.path_text, 0.20 );
			oc_color.path_press   = path_hover;

			oc_color.path_frame2  = n_oc_color_system( COLOR_WINDOW );

			oc_color.info_bg_1    = oc_color.path_hover;

		}

	} else
	if ( oc.style == N_ORANGECAT_STYLE_AQUA )
	{

		oc_color.path_text    = n_oc_color_aqua_path_text();
		oc_color.path_bg      = n_oc_color_aqua_path_bg();
		oc_color.path_hover   = n_oc_color_path_hover();
		oc_color.path_press   = n_bmp_blend_pixel( oc_color.path_bg, N_ORANGECAT_COLOR_BLACK, 0.25 );

		oc_color.item_zebra   = n_bmp_blend_pixel( oc_color.bg, oc_color.item_hover, 0.25 );

	}


	if ( n_win_darkmode_onoff )
	{
		//
	} else {
		if ( ( oc.style == N_ORANGECAT_STYLE_LUNA )||( oc.style == N_ORANGECAT_STYLE_AERO ) )
		{
			oc_color.item_select = n_oc_color_aero_hover();
		} else {
			oc_color.item_select = n_oc_color_item_hover();
		}
	}
	//oc_color.item_select = n_bmp_rgb( 0, 200, 255 );


	oc_color.item_focus = oc_color.item_key_o;


	game.color = oc_color.bg;


	return;
}
