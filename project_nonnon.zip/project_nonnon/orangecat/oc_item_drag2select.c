// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// internal
void
n_oc_item_drag2select_frame_1px( n_bmp *bmp, s32 x, s32 y, s32 sx, s32 sy, u32 fg, u32 bg, bool is_dotted )
{

	if ( n_bmp_error( bmp ) ) { return; }


	s32 fx  = x;
	s32 fy  = y;
	s32 tx  = x + sx - 1;
	s32 ty  = y + sy - 1;


	if ( is_dotted )
	{

		// Top
		n_bmp_line_dot( bmp, fx,fy,tx,fy, fg, 1 );
		n_bmp_line_dot( bmp, fx,fy,tx,fy, bg, 2 );

		// Bottom
		n_bmp_line_dot( bmp, fx,ty,tx,ty, fg, 1 );
		n_bmp_line_dot( bmp, fx,ty,tx,ty, bg, 2 );

		fy++;
		ty--;

		// Left
		n_bmp_line_dot( bmp, fx,fy,fx,ty, fg, 1 );
		n_bmp_line_dot( bmp, fx,fy,fx,ty, bg, 2 );

		// Right
		n_bmp_line_dot( bmp, tx,fy,tx,ty, fg, 1 );
		n_bmp_line_dot( bmp, tx,fy,tx,ty, bg, 2 );

	} else {

		// Top
		n_bmp_line( bmp, fx,fy,tx,fy, fg );

		// Bottom
		n_bmp_line( bmp, fx,ty,tx,ty, fg );

		fy++;
		ty--;

		// Left
		n_bmp_line( bmp, fx,fy,fx,ty, fg );

		// Right
		n_bmp_line( bmp, tx,fy,tx,ty, fg );

	}



	return;
}

void
n_oc_item_drag2select_frame( n_bmp *bmp, s32 x, s32 y, s32 sx, s32 sy, u32 fg, u32 bg, bool is_dotted )
{

	// [x] : scaled frame : remainder is troublesome : see n_oc_lineframe() @ oc_core.c

	//const int unit = 10;
	const int unit = oc.unit_scal;

	if ( sx <= unit ) { return; }
	if ( sy <= unit ) { return; }


	s32 i = 0;
	while( 1 )
	{

		n_oc_item_drag2select_frame_1px( bmp, x + i, y + i, sx - ( i * 2 ), sy - ( i * 2 ), fg, bg, is_dotted );

		i++;
		if ( i >= unit ) { break; }
	}


	return;
}

void
n_oc_item_drag2select_draw( n_oc_item *p )
{
//return;

	if ( n_oc_item_error( p ) ) { return; }


	if ( p->drag2select_onoff == false ) { return; }


	bool is_slowmode = false;


	if ( is_slowmode )
	{

		// [!] : slow mode

		p->is_blank = false;
		n_oc_item_erase( p );

	} else {

		// [!] : fast mode

		s32  x = p->drag2select_px;
		s32  y = p->drag2select_py;
		s32 sx = p->drag2select_psx;
		s32 sy = p->drag2select_psy;

		if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			x -= oc.scrollbar.unit_pos; 
		} else
		if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL   )
		{
			y -= oc.scrollbar.unit_pos;
		}

		u32 color = oc_color.bg;
//color = n_bmp_rgb( 255,0,0 );
		n_bmp_box( &game.bmp, x,y,sx,sy, color );

	}


	n_oc_item_fade( p, false );


	int i = 0;
	while( 1 )
	{//break;

		if ( i >= p->count ) { break; }

		bool redraw = false;

		if ( is_slowmode )
		{

			redraw = true;

		} else {

			if ( oc.view_is_computer )
			{

				redraw = true;

			} else {

				if ( ( p->multifocus[ i ] )||( false == p->fade[ i ].stop ) )
				{
					redraw = true;
//p->fade[ i ].color_fg = n_bmp_rgb( 255,0,0 );
				}

			}

		}

		if ( redraw )
		{
			//n_bmp_fade_redraw( &p->fade[ i ] );
			n_oc_item_draw_single( p, i, true );
		}

		i++;

	}


	{
//n_oc_debug_count();

		s32  x = p->drag2select_x;
		s32  y = p->drag2select_y;
		s32 sx = p->drag2select_sx;
		s32 sy = p->drag2select_sy;


		if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			x -= oc.scrollbar.unit_pos;
		} else
		if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL   )
		{
			y -= oc.scrollbar.unit_pos;
		}

//n_game_hwndprintf_literal( " %d %d %d %d ", x,y,sx,sy );


		if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			double pos  = oc.scrollbar.unit_pos;
			double last = oc.scrollbar.unit_max - oc.scrollbar.unit_page;
			if ( ( pos >= last )&&( ( x + sx ) >= game.sx ) ) { sx = game.sx - x + 1; }
		} else
		if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL   )
		{
			double pos  = oc.scrollbar.unit_pos;
			double last = oc.scrollbar.unit_max - oc.scrollbar.unit_page;
			if ( ( pos >= last )&&( ( y + sy ) >= game.sy ) ) { sy = game.sy - y + 1; }
		}

		if ( ( x + sx ) > (   p->sx                  ) ) { sx =   p->sx                  - x; }
		if ( ( y + sy ) > ( ( p->sy + oc.unit_path ) ) ) { sy = ( p->sy + oc.unit_path ) - y; }


		if ( oc.dragselection_alpha_onoff )
		{

			n_bmp_mixer( &game.bmp, x,y,sx,sy, oc_color.item_select, 0.33 );

			u32 fg = oc_color.item_select;
			u32 bg = oc_color.item_select;

			n_oc_item_drag2select_frame( &game.bmp, x,y,sx,sy, fg, bg, true );

		} else {

			u32 fg = N_ORANGECAT_COLOR_BLACK;
			u32 bg = n_bmp_white;

			n_oc_item_drag2select_frame( &game.bmp, x,y,sx,sy, fg, bg, true );

		}


		p->drag2select_px  = p->drag2select_x;
		p->drag2select_py  = p->drag2select_y;
		p->drag2select_psx = p->drag2select_sx;
		p->drag2select_psy = p->drag2select_sy;

	}


	// [Needed] : when scrroll is not zero

	n_oc_path_draw( &path );


	p->is_blank = false;


	n_game_refresh_on();
	return;
}

void
n_oc_item_drag2select_focus( n_oc_item *p )
{

	if ( p->drag2select_onoff == false ) { return; }


	s32 index_min = p->count;
	s32 index_max = 0;


	int i = 0;
	while( 1 )
	{

		if ( i >= p->count ) { break; }


		s32 fx = 0;
		s32 fy = 0;

		n_oc_item_position_calculate( p, i, &fx, &fy, false );


		s32 tx = fx + n_oc_item_lineselection( p, N_BMP_SX( &p->bmp[ i ] ) );
		s32 ty = fy + N_BMP_SY( &p->bmp[ i ] );


		s32 drag_fx = p->drag2select_x;
		s32 drag_fy = p->drag2select_y;
		s32 drag_tx = drag_fx + p->drag2select_sx;
		s32 drag_ty = drag_fy + p->drag2select_sy;

		if (
			( ( drag_fx < fx )||( drag_fx < tx ) )
			&&
			( ( drag_tx > fx )||( drag_tx > tx ) )
			&&
			( ( drag_fy < fy )||( drag_fy < ty ) )
			&&
			( ( drag_ty > fy )||( drag_ty > ty ) )
		)
		{

			bool hover_onoff = n_oc_item_collision_roundrect( p, i, fx, fy, true );
			if ( hover_onoff )
			{

				bool go = false;

				if ( oc.view_is_computer )
				{
					if ( n_oc_item_comnputer_is_drive( p, i ) ) { go = true; }
				} else {
					go = true;
				}

				if ( go )
				{
					p->multifocus[ i ] =  true;
					p->load_index = i;
					n_oc_item_preload( p, 0 );

					if ( index_min > i ) { index_min = i; }
					if ( index_max < i ) { index_max = i; }
				}

			} else {

				p->multifocus[ i ] = false;

			}

		} else {

			p->multifocus[ i ] = false;

		}


		i++;

	}


	if ( oc.debug_drag2select_onoff )
	{
		n_game_hwndprintf_literal( "%g : %d %d", p->scroll_item_per_line, index_min, index_max );
	}


	return;
}

void
n_oc_item_drag2select_init( n_oc_item *p )
{
//return;

//n_oc_debug_count();


	if ( p->drag2select_onoff ) { return; }


	s32 x = oc.cursor_x;
	s32 y = oc.cursor_y;

	if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		x += oc.scrollbar.unit_pos;
	} else
	if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL )
	{
		y += oc.scrollbar.unit_pos;
	}

	p->drag2select_onoff = true;
	p->drag2select_fx    = x;
	p->drag2select_fy    = y;
	p->drag2select_x     = p->drag2select_fx;
	p->drag2select_y     = p->drag2select_fy;
	p->drag2select_sx    = 0;
	p->drag2select_sy    = 0;

	p->drag2select_px    = p->drag2select_x;
	p->drag2select_py    = p->drag2select_y;
	p->drag2select_psx   = p->drag2select_sx;
	p->drag2select_psy   = p->drag2select_sy;


	if ( p->patch_forced_frame_phase == N_OC_ITEM_FORCED_FRAME_ON_1 )
	{

		p->patch_forced_frame_phase = N_OC_ITEM_FORCED_FRAME_ON_2;

		n_oc_item_multifocus_fade_off( p );

	} else {

		int *focus = n_memory_new_closed( sizeof( int ) * p->count );
		if ( p->is_move_reserved )
		{
			n_memory_copy( p->multifocus, focus, sizeof( int ) * p->count );
		}

		n_oc_item_multifocus_off( p );

		if ( p->is_move_reserved )
		{
			n_memory_copy( focus, p->multifocus_move, sizeof( int ) * p->count );
		}
		n_memory_free_closed( focus );

	}


	return;
}

void
n_oc_item_drag2select_loop( n_oc_item *p )
{
//return;

	if ( p->drag2select_onoff == false ) { return; }


	//if ( oc.scrollbar.drag_onoff ) { return; }


	s32 cursor_x = oc.cursor_x;
	s32 cursor_y = oc.cursor_y;

	if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		cursor_x += oc.scrollbar.unit_pos;
	} else
	if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL )
	{
		cursor_y += oc.scrollbar.unit_pos;
	}

	if ( cursor_x <            0 ) { cursor_x =            0; }
	if ( cursor_y < oc.unit_path ) { cursor_y = oc.unit_path; }


	p->drag2select_sx = abs( cursor_x - p->drag2select_fx );
	p->drag2select_x  = n_posix_min_s32( cursor_x, p->drag2select_fx );

	p->drag2select_sy = abs( cursor_y - p->drag2select_fy );
	p->drag2select_y  = n_posix_min_s32( cursor_y, p->drag2select_fy );

	if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		if ( ( p->drag2select_y + p->drag2select_sy ) >= ( p->sy + oc.unit_path ) )
		{
			p->drag2select_sy = ( p->sy + oc.unit_path ) - p->drag2select_y;
		}
	} else
	if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL )
	{
		if ( ( p->drag2select_x + p->drag2select_sx ) >= ( p->sx                ) )
		{
			p->drag2select_sx = ( p->sx                ) - p->drag2select_x;
		}
	}

/*
	p->drag2select_x  = 100;
	p->drag2select_sx = 100;
	p->drag2select_y  = 100;
	p->drag2select_sy = 100;
*/


	n_oc_item_drag2select_focus( p );


	n_oc_item_drag2select_draw( p );


	return;
}

void
n_oc_item_drag2select_exit( n_oc_item *p )
{
//return;

	if ( p->drag2select_onoff )
	{

		p->drag = N_ORANGECAT_DRAG_NEUTRAL;

		p->drag2select_onoff = false;
		p->drag2select_fx    = 0;
		p->drag2select_fy    = 0;
		p->drag2select_x     = 0;
		p->drag2select_y     = 0;
		p->drag2select_sx    = 0;
		p->drag2select_sy    = 0;

		p->drag2select_px    = 0;
		p->drag2select_py    = 0;
		p->drag2select_psx   = 0;
		p->drag2select_psy   = 0;

		p->is_blank = false;
		n_oc_item_erase( p );
		n_oc_item_draw( p );
		n_oc_path_draw( &path );
		//n_win_scrollbar_refresh( &oc.scrollbar );
		n_game_refresh_on();

	}


	return;
}


