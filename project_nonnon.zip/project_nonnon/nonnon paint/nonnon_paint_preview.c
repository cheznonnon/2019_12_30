// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// the base layer

#include "../nonnon/neutral/bmp/all.c"
#include "../nonnon/win32/win.c"

#include "../nonnon/project/macro.c"




// internal
void
n_paint_preview_cache_exit( HWND hwnd, n_bmp *bmp_cache )
{

	n_bmp_free( bmp_cache );


	return;
}

// internal
void
n_paint_preview_cache_init( HWND hwnd, n_bmp *bmp_cache )
{

	n_paint_preview_cache_exit( hwnd, bmp_cache );


	s32 tsx,tsy;
	n_win_size_client( hwnd, &tsx, &tsy );


	s32 bmpsx = tsx;
	s32 bmpsy = tsy;

	if ( n_bmp_error( &n_paint_bmp_data ) )
	{

		n_bmp_new( bmp_cache, bmpsx, bmpsy );

	} else {

		bmpsx = N_BMP_SX( &n_paint_bmp_data );
		bmpsy = N_BMP_SY( &n_paint_bmp_data );

		n_bmp_carboncopy( &n_paint_bmp_data, bmp_cache );

		n_paint_grabber_composition( bmp_cache, true );

	}


	if ( ( bmpsx > tsx )||( bmpsy > tsy ) )
	{

		double ratio = 1.0;

		if ( bmpsx > bmpsy )
		{
			ratio = (double) tsx / bmpsx;
		} else {
			ratio = (double) tsy / bmpsy;
		}

		n_bmp_resampler( bmp_cache, ratio, ratio );

	}


	n_bmp_resizer( bmp_cache, tsx,tsy, n_bmp_black_invisible, N_BMP_RESIZER_CENTER );


	if ( n_paint_format_is_curico( n_paint_bmpname ) )
	{
		n_bmp_flush_replacer( bmp_cache, n_bmp_trans, n_bmp_black_invisible );
	}


	if ( n_paint_format_is_ico( n_paint_bmpname ) )
	{
		n_bmp_flush_replacer( bmp_cache, n_bmp_black_invisible, n_gdi_systemcolor( COLOR_WINDOW ) );
	} else
	if ( ( n_paint_format_is_cur( n_paint_bmpname ) )&&( false == n_project_dwm_is_on() ) )
	{
		n_bmp_flush_replacer( bmp_cache, n_bmp_black_invisible, n_gdi_systemcolor( COLOR_DESKTOP ) );
	}


	return;
}

void
n_paint_preview_resize( HWND hwnd )
{

	s32 desktop_sx, desktop_sy;
	n_win_desktop_size( &desktop_sx, &desktop_sy );

	s32 cs = (double) n_posix_min_s32( desktop_sx, desktop_sy ) * 0.8;

	n_win_set( hwnd, NULL, cs, cs, N_WIN_SET_CENTERING );


	return;
}

void
n_paint_preview_draw( HWND hwnd, const n_bmp *bmp )
{

	if ( n_bmp_error( bmp ) ) { return; }


	HDC hdc = GetDC( hwnd );
	if ( hdc == NULL ) { return; }


	BITMAPINFO bi = { N_BMP_INFOH( bmp ), { { 0,0,0,0 } } };

	HBITMAP hbmp = CreateDIBitmap
	(
		hdc,
		&bi.bmiHeader,
		CBM_INIT,
		N_BMP_PTR( bmp ),
		&bi,
		DIB_RGB_COLORS
	);


	s32 fsx = N_BMP_SX( bmp );
	s32 fsy = N_BMP_SY( bmp );

	s32 tsx,tsy;
	n_win_size_client( hwnd, &tsx, &tsy );


	HDC     hdc_compat = CreateCompatibleDC( hdc );
	HBITMAP hbmp_old   = SelectObject( hdc_compat, hbmp );

	SetStretchBltMode( hdc, COLORONCOLOR );
	StretchBlt( hdc, 0,0,tsx,tsy, hdc_compat, 0,0,fsx,fsy, SRCCOPY );

	SelectObject( hdc_compat, hbmp_old );
	DeleteDC( hdc_compat );


	n_win_bitmap_exit( hbmp );

	ReleaseDC( hwnd, hdc );


	return;
}

LRESULT CALLBACK
n_paint_preview_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_bmp bmp_cache;


	n_win_simplemenu_xmouse( &n_paint_simplemenu, hwnd, msg );


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_win_ime_disable( hwnd );

		n_bmp_zero( &bmp_cache );


		// Window

		n_win_init_literal( hwnd, "Preview", "NONNON_PAINT_0_MAIN", "" );


		// Style

		n_win_style_new( hwnd, N_WS_POPUPWINDOW | WS_SIZEBOX );
		//n_win_style_new( hwnd, WS_POPUP | WS_SIZEBOX );

		if ( n_project_dwm_is_on() ) { n_win_dwm_transparent_on( hwnd ); }


		// Init

		if (
			( n_posix_stat_is_exist( n_paint_bmpname ) )
			&&
			( n_paint_format_is_cur( n_paint_bmpname ) )
		)
		{
			n_win_cursor_add( hwnd, n_paint_bmpname );
		}

		n_paint_preview_resize( hwnd );
		n_paint_preview_cache_init( hwnd, &bmp_cache );
		n_paint_preview_draw( hwnd, &bmp_cache );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

		EnableWindow( hwnd_tool, false );
		EnableWindow( hwnd_main, false );

	break;


	case WM_ERASEBKGND :

		return true;

	break;

	case WM_PAINT :
	case WM_SIZE  :

		n_paint_preview_draw( hwnd, &bmp_cache );

	break;


	case WM_LBUTTONDBLCLK :

		n_paint_preview_resize( hwnd );
		//n_paint_preview_cache_init( hwnd, &bmp_cache );
		n_paint_preview_draw( hwnd, &bmp_cache );

	break;


	case WM_KEYDOWN :

		// [!] : for toggling : see n_paint_tool_input_proc()

		if ( wparam == '1' )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		}

	break;


	case WM_CLOSE :

		EnableWindow( hwnd_tool, true );
		EnableWindow( hwnd_main, true );

		n_paint_preview_cache_exit( hwnd, &bmp_cache );

		n_win_cursor_del( hwnd );

		DestroyWindow( hwnd );

	break;


	} // switch


	n_paint_sync_proc( hwnd, msg, wparam, lparam );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

