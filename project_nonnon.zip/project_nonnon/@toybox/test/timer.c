



#include <stdio.h>
#include <string.h>


#include <windows.h>
#include <mmsystem.h>




void
n_timer_precision_check( void )
{

	char  str[ 100 ];

	int   i;

	DWORD f,t, ret_f[ 5 ], ret_t[ 5 ];


	i = 0;
	while( 1 )
	{

		f = GetTickCount();
		t = timeGetTime();

		Sleep( 1 );

		ret_f[ i ] = GetTickCount() - f;
		ret_t[ i ] = timeGetTime()  - t;

		i++;
		if ( i >= 5 ) { break; }
	}

	i = 0;
	while( 1 )
	{

		sprintf( str, "#%d : %d - %d", i, (int)ret_f[ i ], (int)ret_t[ i ] );

		MessageBoxA( NULL, str, "Result", 0 );


		i++;
		if ( i >= 5 ) { break; }
	}


	return;
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{

	char     str[ 100 ];

	TIMECAPS tc;


	ZeroMemory( &tc, sizeof( TIMECAPS ) );

	timeGetDevCaps( &tc, sizeof( TIMECAPS ) );


	sprintf( str, "%d : %d", tc.wPeriodMin, tc.wPeriodMax );

	MessageBoxA( NULL, str, "Precision", 0 );


	// Before

	n_timer_precision_check();


	// After

	timeBeginPeriod( tc.wPeriodMin );

	n_timer_precision_check();

	timeEndPeriod( tc.wPeriodMin );


	return 0;
}

